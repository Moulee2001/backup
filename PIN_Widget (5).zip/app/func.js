
var loginuser=null;
$(document).on("click","#submit",function(event){
  $(this).find("span").text("Please Wait");
  $(this).prop("disabled", true);
  // $('.buttonload .fa-spin').css('display', 'block');
  event.preventDefault();
  var field1 = $(".input-field input:eq(0)").val();
  var field2 = $(".input-field input:eq(1)").val();
  var field3 = $(".input-field input:eq(2)").val();
  var field4 = $(".input-field input:eq(3)").val();

  var concatenatedValue = field1 + field2 + field3 + field4;
  console.log(concatenatedValue);
  var finalinput=Number(concatenatedValue);
  console.log("finalinput:",finalinput);
  CheckCarerPinFunc(finalinput).then(respdata=>{
    console.log("respdata:",respdata);
    if(respdata !=null)
    {
      const carerPin=respdata[0]["Carers.Carer_Pin"];
      console.log("carerPin:",carerPin);
      const CarerID=respdata[0].CarersrecID;
      const clientID=respdata[0].Clients.ID;
      // window.open(portalUrl+"#Page:PIN_Report?carerid="+CarerID,"_top");
      var param = {
        action: "open",url: "#Page:PIN_Report?carerid="+CarerID+"&clientid="+clientID, window: "same"
      };
      ZOHO.CREATOR.UTIL.navigateParentURL(param);
    }
    else
    {
      Swal.fire({   
        title:"Mismatch",   
        text:"The Provided PIN does not match",   
        icon:"error",
        showConfirmButton: false,
        timer: 2000
      }).then(function() {
        location.reload(true);
      });
    }
  });
});

async function CheckCarerPinFunc(finalinput){
  var returnVal=null;
  // var config = { 
  //   // appName : "hcd-admin",
  //   reportName : "Carers_Report",
  //   // criteria : '(Carer_Pin == '+finalinput+' && Email =="'+loginuser+'")',
  //   criteria : '(Carer_Pin == '+finalinput+')',
  //   // criteria : '(Formula =="zohosupport@thoughtlogik.com")',
  //   page : 1,
  //   pageSize : 100
  // }
  var config = { 
    reportName : "Client_Carers_Report",
    // criteria : '(Carers.Carer_Pin == '+finalinput+' && Clients.Client_Portal_Email =="'+loginuser+'")',
    criteria : '(Carers.Carer_Pin == '+finalinput+' && Clients.Client_Portal_Email.contains("'+loginuser+'"))',
    // criteria : '(Carer_Pin == '+finalinput+')',
    page : 1,
    pageSize : 100
  }
  console.log("config:",config);
  try{
    const CarerResponse = await ZOHO.CREATOR.API.getAllRecords(config);
    console.log("CarerResponse:",CarerResponse);
    const recordArr = await CarerResponse.data;
    returnVal=recordArr;
  }catch(error){
    console.log("error:",error);
  }
  return returnVal;
}

ZOHO.CREATOR.init().then(function(data) {
  var initparams = ZOHO.CREATOR.UTIL.getInitParams();
  console.log("initparams:",initparams);
  var usename=initparams.loginUser;
  console.log("usename:",usename);
  loginuser=usename;
});