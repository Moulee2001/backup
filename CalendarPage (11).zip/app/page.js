$("#multiplecarer").select2({
  placeholder: "Select Carer",
  allowClear: true,
  closeOnSelect: false
});
$(document).on('click', '#next', function() {
  const nextStartDate = new Date(currentWeek.startDate);
  nextStartDate.setDate(currentWeek.startDate.getDate() + 7); // Adding 7 days for next week
  const nextEndDate = new Date(currentWeek.endDate);
  nextEndDate.setDate(currentWeek.endDate.getDate() + 7); // Adding 7 days for next week
  currentWeek = { startDate: nextStartDate, endDate: nextEndDate };
  displayWeekDetails(nextStartDate, nextEndDate);
  $("#week_details").css("width", "94%");
  $("#previous_btns_details").css("width", "2%");
  $("#current_btns_details").css("width", "2%");
   $("#left_btns_details").css("width", "2%");
  $("#current_btns_details").css("display", "block");
});
// Current Button Function
$(document).on('click', '#current', function(){
  currentWeek = getCurrentWeekDetails();
  displayWeekDetails(currentWeek.startDate, currentWeek.endDate);
  $("#current_btns_details").css("display", "none");
  $("#week_details").css("width", "96%");
  $("#previous_btns_details").css("width", "2%");
     $("#left_btns_details").css("width", "2%");
     var currentDate = new Date();
     // Format the date as YYYY-MM-DD (required for input type="date")
     var formattedDate = currentDate.toISOString().slice(0,10);
     // Set the value of the input field with id "selectedDate"
     $('#selectedDate').val(formattedDate);
});

// Function to handle previous week button click
$(document).on('click', '#previous', function(){
  const previousStartDate = new Date(currentWeek.startDate);
  previousStartDate.setDate(currentWeek.startDate.getDate() - 7); // Subtracting 7 days for previous week
  const previousEndDate = new Date(currentWeek.endDate);
  previousEndDate.setDate(currentWeek.endDate.getDate() - 7); // Subtracting 7 days for previous week
  currentWeek = { startDate: previousStartDate, endDate: previousEndDate };
  displayWeekDetails(previousStartDate, previousEndDate);
  $("#week_details").css("width", "94%");
  $("#previous_btns_details").css("width", "2%");
  $("#current_btns_details").css("width", "2%");
   $("#left_btns_details").css("width", "2%");
  $("#current_btns_details").css("display", "block");
});

function DisplayShiftDetails_Func() {
  $('#datesBody').empty();

  var CarerOptions = $(".carerdataDD").select2('data');
  var carernameValues = CarerOptions.map(function (option) {
    return { carername: option.element.getAttribute('carer_name') };
  });
  var ClientOptions = $(".clientdataDD").select2('data');
  var clientnameValues = ClientOptions.map(function (option) {
    return { clientname: option.element.getAttribute('client_name') };
  });
  var CareFaciOptions = $(".carefacidataDD").select2('data');
  var carefaciValues = CareFaciOptions.map(function (option) {
    return { carefaciname: option.element.getAttribute('care_facilitier_name') };
  });
  PostShift_TO_Table_Func(carernameValues, clientnameValues, carefaciValues);
}

//Function for Filter Part
var changeEventTriggered = false;
$(document).delegate('.carerdataDD, .clientdataDD, .carefacidataDD', 'change', function(){
  $('#datesBody').empty();
  var CarerOptions = $(".carerdataDD").select2('data');
  var carernameValues = CarerOptions.map(function (option) {
    return { carername: option.element.getAttribute('carer_name') };
  });
  var ClientOptions = $(".clientdataDD").select2('data');
  var clientnameValues = ClientOptions.map(function (option) {
    return { clientname: option.element.getAttribute('client_name') };
  });
  var CareFaciOptions = $(".carefacidataDD").select2('data');
  var carefaciValues = CareFaciOptions.map(function (option) {
    return { carefaciname: option.element.getAttribute('care_facilitier_name') };
  });
  PostShift_TO_Table_Func(carernameValues, clientnameValues, carefaciValues);
});

// Filter Reset button script
$(document).delegate(".resetfilter", 'click', function(){
  console.log("resetfilter button clicked");

  $(".carerdataDD, .clientdataDD, .carefacidataDD").val([]).trigger("change");

  $('#datesBody').empty();
  for (const Empelement of carerArr) {
    const empName = Empelement.carerName;
    const carerID = Empelement.carerID;
    var imageattrID="img-"+Empelement.carerID;
    const zohoImage=Empelement.Image || "";
    var bodyhtml='<td class="emp_td" carerID="'+carerID+'" orginimage="'+zohoImage+'"><img class="tableimage" id="'+imageattrID+'" src="NoProfile.jpg" orginimage="'+zohoImage+'" ><span>'+empName+'</span></td>';
    

    $('#datesRow th').each(function() {
      var DateCurrent=$(this).attr("currentdate");
      const searchResult = searchRecord(shiftDataArr,empName,DateCurrent);
      if (searchResult.length>0)
      {
        var divcontent="";
        for (let sp = 0; sp < searchResult.length; sp++)
        {
          const ShiftName = searchResult[sp].concat_shift_name;
          var splitParts = ShiftName.split(/\[|\]/);
          var shiftname = splitParts[0].trim();
          var shiftdate = splitParts[1].trim();
          var shiftColor = searchResult[sp].Card_Color;
          if (shiftColor != "")
          {
            console.log("shiftColorinif", shiftColor);
            divcontent += "<div class='empdiv' style='border-top: 3px solid " + shiftColor + "; border-bottom: 3px solid " + shiftColor + "; border-left: 10px solid " + shiftColor + "; border-right: 3px solid " + shiftColor + ";' carer_id='" + searchResult[sp].carer_id + "' client_id='" + searchResult[sp].client_id + "' carer_name='" + searchResult[sp].EmpName + "' shift_name='" + searchResult[sp].shift + "' shift_id='" + searchResult[sp].shiftid + "' client_name='" + searchResult[sp].client + "' start_date='" + searchResult[sp].schstartdt + "' end_date='" + searchResult[sp].schenddt + "' recid='" + searchResult[sp].rec_id + "' shiftstarttime='" + searchResult[sp].shiftstarttime + "' shiftendtime='" + searchResult[sp].shiftendtime + "' shifttype='" + searchResult[sp].shifttype + "' endday='" + searchResult[sp].endday + "'>" + shiftname + "<br>" + shiftdate + "</div>";
          }
          else if(shiftColor == "")
          {
            shiftColor = "red";
            console.log("shiftColorinelse", shiftColor);
            divcontent += "<div class='empdiv' style='border-top: 3px solid " + shiftColor + "; border-bottom: 3px solid " + shiftColor + "; border-left: 10px solid " + shiftColor + "; border-right: 3px solid " + shiftColor + ";' carer_id='" + searchResult[sp].carer_id + "' client_id='" + searchResult[sp].client_id + "' carer_name='" + searchResult[sp].EmpName + "' shift_name='" + searchResult[sp].shift + "' shift_id = '" + searchResult[sp].shiftid + "' client_name='" + searchResult[sp].client + "' start_date='" + searchResult[sp].schstartdt + "' end_date='" + searchResult[sp].schenddt + "' recid='" + searchResult[sp].rec_id + "' shiftstarttime='" + searchResult[sp].shiftstarttime + "' shiftendtime='" + searchResult[sp].shiftendtime + "' shifttype='" + searchResult[sp].shifttype + "' endday='" + searchResult[sp].endday + "'>" + shiftname + "<br>" + shiftdate + "</div>";
          }
        }
        divcontent+="<div class='empbtn' currentdate='"+DateCurrent+"'>+</div>";
        bodyhtml+="<td>"+divcontent+"</td>";
      }
      else
      {
        bodyhtml+="<td class='empbtn' currentdate='"+DateCurrent+"'>+</td>";
      }
    });
    $('#datesBody').append("<tr>"+bodyhtml+"</tr>");
    var imgData="#img-"+carerID;
    let imgTag = document.querySelector(imgData);
    var imageFromGetRecordsAPI=imgTag.getAttribute("orginimage");
    if (imageFromGetRecordsAPI!="") {
      ZOHO.CREATOR.UTIL.setImageData(imgTag, zohoImage);
    }
    // else
    // {
    //   const defaultImage="/api/v2/homecaredirect/hcd-admin/report/Clients_Profile_Images_Report/134556000002408039/Clients_Image_test/download?filepath=1712662542081_240_F_65772719_A1UV5kLi5nCEWI0BNLLiFaBPEkUbv5Fv.jpg";
    //   ZOHO.CREATOR.UTIL.setImageData(imgTag, defaultImage);
    // }
    $(".resetfilter").attr("disabled",true);
  }
});
// Filter Reset button script ends

async function PostShift_TO_Table_Func(carernameValues,clientnameValues,carefaciValues){ // Testing Code by sp
  var resultData = generateCombinations(carernameValues, clientnameValues, carefaciValues);
  resultData = resultData.filter(function(item) {
    return item.trim() !== '{}';
  });
  console.log("resultData:",resultData);

  if (resultData.length>0)
  {
    $(".resetfilter").attr("disabled",false);
    var CarerClientDataArr = [];
    resultData.forEach(element=>{
      var jsonObject = JSON.parse(element);
      console.log("jsonObject:",jsonObject);
      const keysToCheck = ['carername', 'clientname', 'carefaciname'];

      const allKeysExist = keysToCheck.every(key => jsonObject.hasOwnProperty(key));
      if (allKeysExist) // client and careFaci function
      {
        var clientName = jsonObject.clientname;
        var carefaciName = jsonObject.carefaciname;
        var carerName = jsonObject.carername;
        var CarerClientUnique = removeDuplicates(wholeCareClient, ['carerName','clientName','careFaciName']);
        const CarerClientuniqueData = CarerClientUnique.filter(item => item.clientName === clientName && item.carerName === carerName && item.careFaciName === carefaciName);
        if (CarerClientuniqueData.length>0)
        {
          CarerClientuniqueData.forEach(element => {
            element["filterType"]="carerclientcarefaci";
            CarerClientDataArr.push(element); 
          }); 
        }
      }
      else if (checkProperties(jsonObject, ['clientname', 'carefaciname'])) // client and careFaci function
      {
        var clientName = jsonObject.clientname;
        var carefaciName = jsonObject.carefaciname;
        var CarerClientUnique = removeDuplicates(wholeCareClient, ['carerName','clientName','careFaciName']);
        const CarerClientuniqueData = CarerClientUnique.filter(item => item.clientName === clientName && item.careFaciName === carefaciName);
        if (CarerClientuniqueData.length>0)
        {
          CarerClientuniqueData.forEach(element => {
            element["filterType"]="clientcarefaci";
            CarerClientDataArr.push(element); 
          }); 
        }
      }
      else if (checkProperties(jsonObject, ['carername', 'carefaciname'])) // carer and carefaci Filter
      {
        var carerName = jsonObject.carername;
        var carefaciName = jsonObject.carefaciname;
        var CarerClientUnique = removeDuplicates(wholeCareClient, ['carerName','clientName','careFaciName']);
        const CarerClientuniqueData = CarerClientUnique.filter(item => item.carerName === carerName && item.careFaciName === carefaciName);
        if (CarerClientuniqueData.length>0)
        {
          CarerClientuniqueData.forEach(element => {
            element["filterType"]="carercarefaci";
            CarerClientDataArr.push(element); 
          }); 
        }
      }
      else if (checkProperties(jsonObject, ['carername', 'clientname'])) // Carer Name and Client Name filter
      {
        var carerName = jsonObject.carername;
        var clientName = jsonObject.clientname;
        var CarerClientUnique = removeDuplicates(wholeCareClient, ['carerName', 'clientName']);
        var CarerClientuniqueData = CarerClientUnique.filter(item=> item.carerName === carerName && item.clientName === clientName);
        if (CarerClientuniqueData.length>0)
        {
          CarerClientuniqueData.forEach(element => {
            element["filterType"]="clientcarer";
            CarerClientDataArr.push(element); 
          }); 
        }
      }
      else if (jsonObject.hasOwnProperty('carername')) // carerName filter
      {
        var carername = jsonObject.carername;
        const CarerClientUnique = removeDuplicatesByKey(wholeCareClient, 'carerName');
        const CarerClientuniqueData = CarerClientUnique.filter(item => item.carerName ==carername);
        if (CarerClientuniqueData.length>0)
        {
          CarerClientuniqueData.forEach(element => {
            element["filterType"]="carer";
            CarerClientDataArr.push(element); 
          }); 
        }
      }
      else if (jsonObject.hasOwnProperty('clientname')) // Client name filter
      {
        var clientName = jsonObject.clientname;
        var CarerClientUnique = removeDuplicates(wholeCareClient, ['carerName', 'clientName']);
        const CarerClientuniqueData = CarerClientUnique.filter(item => item.clientName ==clientName);
        if (CarerClientuniqueData.length>0)
        {
          CarerClientuniqueData.forEach(element => {
            element["filterType"]="client";
            CarerClientDataArr.push(element); 
          }); 
        }
      }
      else if (jsonObject.hasOwnProperty('carefaciname')) // Care Faci Name filter
      {
        var carefaciName = jsonObject.carefaciname;
        var uniqueDataTemp = removeDuplicates(wholeCareClient, ['carerName','clientName','careFaciName']);
        const uniqueCareFaciData = uniqueDataTemp.filter(item => item.careFaciName === carefaciName);
        if (uniqueCareFaciData.length>0)
        {
          uniqueCareFaciData.forEach(element => {
            element["filterType"]="careFaci";
            CarerClientDataArr.push(element); 
          }); 
        }
      }
    });
    console.log("CarerClientDataArr:",CarerClientDataArr);
    if (CarerClientDataArr.length>0)
    {
      // FindandAppend_Filtered_ShiftDetailstest (CarerClientDataArr);
      FindandAppend_Filtered_ShiftDetails (CarerClientDataArr);  
    }
    else
    {
      var bodyhtml="<td colspan='8'>No mapping records were found for this search data</td>";
      $('#datesBody').append("<tr>"+bodyhtml+"</tr>");
      // Swal.fire({
      //   title: "No mapping records were found for this search data",
      //   icon: "info",
      //   showConfirmButton :false,
      //   timer: 2500
      // });
    }
  }
  else
  {
    for (const Empelement of carerArr) {
      const empName = Empelement.carerName;
      const carerID = Empelement.carerID;
      var imageattrID="img-"+Empelement.carerID;
      const zohoImage=Empelement.Image || "";
      var bodyhtml='<td class="emp_td" carerID="'+carerID+'" orginimage="'+zohoImage+'"><img class="tableimage" id="'+imageattrID+'" src="NoProfile.jpg" orginimage="'+zohoImage+'" ><span>'+empName+'</span></td>';
      

      $('#datesRow th').each(function() {
        var DateCurrent=$(this).attr("currentdate");
        const searchResult = searchRecord(shiftDataArr,empName,DateCurrent);
        if (searchResult.length>0)
        {
          var divcontent="";
          for (let sp = 0; sp < searchResult.length; sp++)
          {
            const ShiftName = searchResult[sp].concat_shift_name;
            var splitParts = ShiftName.split(/\[|\]/);
            var shiftname = splitParts[0].trim();
            var shiftdate = splitParts[1].trim();
            var shiftColor = searchResult[sp].Card_Color;
            if (shiftColor != "")
            {
              console.log("shiftColorinif", shiftColor);
              divcontent += "<div class='empdiv' style='border-top: 3px solid " + shiftColor + "; border-bottom: 3px solid " + shiftColor + "; border-left: 10px solid " + shiftColor + "; border-right: 3px solid " + shiftColor + ";' carer_id='" + searchResult[sp].carer_id + "' client_id='" + searchResult[sp].client_id + "' carer_name='" + searchResult[sp].EmpName + "' shift_name='" + searchResult[sp].shift + "' shift_id='" + searchResult[sp].shiftid + "' client_name='" + searchResult[sp].client + "' start_date='" + searchResult[sp].schstartdt + "' end_date='" + searchResult[sp].schenddt + "' recid='" + searchResult[sp].rec_id + "' shiftstarttime='" + searchResult[sp].shiftstarttime + "' shiftendtime='" + searchResult[sp].shiftendtime + "' shifttype='" + searchResult[sp].shifttype + "' endday='" + searchResult[sp].endday + "'>" + shiftname + "<br>" + shiftdate + "</div>";
            }
            else if(shiftColor == "")
            {
              shiftColor = "red";
              console.log("shiftColorinelse", shiftColor);
              divcontent += "<div class='empdiv' style='border-top: 3px solid " + shiftColor + "; border-bottom: 3px solid " + shiftColor + "; border-left: 10px solid " + shiftColor + "; border-right: 3px solid " + shiftColor + ";' carer_id='" + searchResult[sp].carer_id + "' client_id='" + searchResult[sp].client_id + "' carer_name='" + searchResult[sp].EmpName + "' shift_name='" + searchResult[sp].shift + "' shift_id = '" + searchResult[sp].shiftid + "' client_name='" + searchResult[sp].client + "' start_date='" + searchResult[sp].schstartdt + "' end_date='" + searchResult[sp].schenddt + "' recid='" + searchResult[sp].rec_id + "' shiftstarttime='" + searchResult[sp].shiftstarttime + "' shiftendtime='" + searchResult[sp].shiftendtime + "' shifttype='" + searchResult[sp].shifttype + "' endday='" + searchResult[sp].endday + "'>" + shiftname + "<br>" + shiftdate + "</div>";
            }
          }
          divcontent+="<div class='empbtn' currentdate='"+DateCurrent+"'>+</div>";
          bodyhtml+="<td>"+divcontent+"</td>";
        }
        else
        {
          bodyhtml+="<td class='empbtn' currentdate='"+DateCurrent+"'>+</td>";
        }
      });
      $('#datesBody').append("<tr>"+bodyhtml+"</tr>");
      var imgData="#img-"+carerID;
      let imgTag = document.querySelector(imgData);
      var imageFromGetRecordsAPI=imgTag.getAttribute("orginimage");
      if (imageFromGetRecordsAPI!="") {
        ZOHO.CREATOR.UTIL.setImageData(imgTag, zohoImage);
      }
      else
      {
        // const defaultImage="/api/v2/homecaredirect/hcd-admin/report/Clients_Profile_Images_Report/134556000002408039/Clients_Image_test/download?filepath=1712662542081_240_F_65772719_A1UV5kLi5nCEWI0BNLLiFaBPEkUbv5Fv.jpg";
        // ZOHO.CREATOR.UTIL.setImageData(imgTag, defaultImage);
      }
    }
  }
}

// function FindandAppend_Filtered_ShiftDetailstest (CarerClientDataArr){
//   console.log("FindandAppend_Filtered_ShiftDetailstest:");
//   var result = groupByCarerName(CarerClientDataArr);
//   console.log("result:",result);
//   Object.keys(result).forEach(key => {
//     const carername = key; // Extract the name from the key
//     const findCarerIDByName = (wholeCareClient, CarerName) => wholeCareClient.find(item => item.carerName === CarerName)?.carerID || null;
//     const carerID = findCarerIDByName(wholeCareClient, carername);
//     var bodyhtml = "<td class='emp_td' carerID='" + carerID + "'>" + carername + "</td>";
//     var divcontent="";

//     $('#datesRow th').each(function() {
//       var DateCurrent=$(this).attr("currentdate");
//       var outsideResult=0;
//       result[carername].forEach(function(itemData){
//         console.log("Item:",itemData);
//         var carerName=itemData.carerName;
//         var clientName=itemData.clientName;
//         var carefaciName=itemData.careFaciName;
//         const searchResult = searchRecord_With_Filter(shiftDataArr,carerName,clientName,carefaciName,DateCurrent);
//         console.log("searchResult:",searchResult);
//         if (searchResult.length>0)
//         {
//           outsideResult=1;
//           for (let sp = 0; sp < searchResult.length; sp++)
//           {
//             const ShiftName = searchResult[sp].concat_shift_name;
//             var splitParts = ShiftName.split(/\[|\]/);
//             var shiftname = splitParts[0].trim();
//             var shiftdate = splitParts[1].trim();
//             divcontent+="<div class='empdiv' carer_id='"+searchResult[sp].carer_id+"' client_id='"+searchResult[sp].client_id+"' carer_name='"+searchResult[sp].EmpName+"' shift_name='"+searchResult[sp].shift+"' shift_id = '"+searchResult[sp].shiftid+"' client_name='"+searchResult[sp].client+"' start_date='"+searchResult[sp].schstartdt+"' end_date='"+searchResult[sp].schenddt+"' recid='"+searchResult[sp].rec_id+"' shiftstarttime='"+searchResult[sp].shiftstarttime+"' shiftendtime='"+searchResult[sp].shiftendtime+"' shifttype='"+searchResult[sp].shifttype+"' endday='"+searchResult[sp].endday+"'>"+shiftname+ "<br>"+shiftdate+"</div>";
//           }
//         }
//       });
//       if (outsideResult==0)
//       {
//         bodyhtml+="<td class='empbtn' currentdate='"+DateCurrent+"'>+</td>";
//       }
//       else
//       {
//         divcontent+="<div class='empbtn' currentdate='"+DateCurrent+"'>+</div>";
//         bodyhtml+="<td>"+divcontent+"</td>";
//       }
//     });
//     $('#datesBody').append("<tr>"+bodyhtml+"</tr>");
//   });
// }



function FindandAppend_Filtered_ShiftDetails (CarerClientDataArr){
  $("#datesBody").empty();
  var result = groupByCarerName(CarerClientDataArr);
  Object.keys(result).forEach(key => {
    const carername = key; // Extract the name from the key
    const findCarerInfoByName = (wholeCareClient, carerName) => {
      const carer = wholeCareClient.find(item => item.carerName === carerName);
      if (carer) {
        return { carerID: carer.carerID, carerImage: carer.carerImage };
      } else {
        return { carerID: null, carerImage: null };
      }
    };
  
    const carerInfo = findCarerInfoByName(wholeCareClient, carername);
    const carerID = carerInfo.carerID;
    const carerImage = carerInfo.carerImage;
    var imageattrID="img-"+carerID;
    const zohoImage=carerImage;
    var bodyhtml = "<td class='emp_td' carerID='" + carerID + "'><img class='tableimage' id='"+imageattrID+"' src='NoProfile.jpg' orginimage='"+zohoImage+"' ><span>"+ carername + "</span></td>";
    // var divcontent="";

    $('#datesRow th').each(function() {
      var DateCurrent=$(this).attr("currentdate");
      var divcontent="";
      var outsideResult=0;
      result[carername].forEach(function(itemData){
        var carerName=itemData.carerName;
        var clientName=itemData.clientName;
        var carefaciName=itemData.careFaciName;
        var FilterType=itemData.filterType;
        if (FilterType=="carerclientcarefaci")
        {
          const searchResult = searchRecord_With_Filter(shiftDataArr,carerName,clientName,carefaciName,DateCurrent);
          if (searchResult.length>0)
          {
            outsideResult=1;
            for (let sp = 0; sp < searchResult.length; sp++)
            {
              const ShiftName = searchResult[sp].concat_shift_name;
              var splitParts = ShiftName.split(/\[|\]/);
              var shiftname = splitParts[0].trim();
              var shiftdate = splitParts[1].trim();
              var shiftColor = searchResult[sp].Card_Color;
              if (shiftColor != "")
              {
                console.log("shiftColorinif", shiftColor);
                divcontent += "<div class='empdiv' style='border-top: 3px solid " + shiftColor + "; border-bottom: 3px solid " + shiftColor + "; border-left: 10px solid " + shiftColor + "; border-right: 3px solid " + shiftColor + ";' carer_id='" + searchResult[sp].carer_id + "' client_id='" + searchResult[sp].client_id + "' carer_name='" + searchResult[sp].EmpName + "' shift_name='" + searchResult[sp].shift + "' shift_id='" + searchResult[sp].shiftid + "' client_name='" + searchResult[sp].client + "' start_date='" + searchResult[sp].schstartdt + "' end_date='" + searchResult[sp].schenddt + "' recid='" + searchResult[sp].rec_id + "' shiftstarttime='" + searchResult[sp].shiftstarttime + "' shiftendtime='" + searchResult[sp].shiftendtime + "' shifttype='" + searchResult[sp].shifttype + "' endday='" + searchResult[sp].endday + "'>" + shiftname + "<br>" + shiftdate + "</div>";
              }
              else if(shiftColor == "")
              {
                shiftColor = "red";
                console.log("shiftColorinelse", shiftColor);
                divcontent += "<div class='empdiv' style='border-top: 3px solid " + shiftColor + "; border-bottom: 3px solid " + shiftColor + "; border-left: 10px solid " + shiftColor + "; border-right: 3px solid " + shiftColor + ";' carer_id='" + searchResult[sp].carer_id + "' client_id='" + searchResult[sp].client_id + "' carer_name='" + searchResult[sp].EmpName + "' shift_name='" + searchResult[sp].shift + "' shift_id = '" + searchResult[sp].shiftid + "' client_name='" + searchResult[sp].client + "' start_date='" + searchResult[sp].schstartdt + "' end_date='" + searchResult[sp].schenddt + "' recid='" + searchResult[sp].rec_id + "' shiftstarttime='" + searchResult[sp].shiftstarttime + "' shiftendtime='" + searchResult[sp].shiftendtime + "' shifttype='" + searchResult[sp].shifttype + "' endday='" + searchResult[sp].endday + "'>" + shiftname + "<br>" + shiftdate + "</div>";
              }
            }
          }  
        }
        else if (FilterType=="clientcarefaci")
        {
          const searchResult = searchRecord_With_Filter(shiftDataArr,carerName,clientName,carefaciName,DateCurrent);
          if (searchResult.length>0)
          {
            outsideResult=1;
            for (let sp = 0; sp < searchResult.length; sp++)
            {
              const ShiftName = searchResult[sp].concat_shift_name;
              var splitParts = ShiftName.split(/\[|\]/);
              var shiftname = splitParts[0].trim();
              var shiftdate = splitParts[1].trim();
              var shiftColor = searchResult[sp].Card_Color;
              if (shiftColor != "")
              {
                console.log("shiftColorinif", shiftColor);
                divcontent += "<div class='empdiv' style='border-top: 3px solid " + shiftColor + "; border-bottom: 3px solid " + shiftColor + "; border-left: 10px solid " + shiftColor + "; border-right: 3px solid " + shiftColor + ";' carer_id='" + searchResult[sp].carer_id + "' client_id='" + searchResult[sp].client_id + "' carer_name='" + searchResult[sp].EmpName + "' shift_name='" + searchResult[sp].shift + "' shift_id='" + searchResult[sp].shiftid + "' client_name='" + searchResult[sp].client + "' start_date='" + searchResult[sp].schstartdt + "' end_date='" + searchResult[sp].schenddt + "' recid='" + searchResult[sp].rec_id + "' shiftstarttime='" + searchResult[sp].shiftstarttime + "' shiftendtime='" + searchResult[sp].shiftendtime + "' shifttype='" + searchResult[sp].shifttype + "' endday='" + searchResult[sp].endday + "'>" + shiftname + "<br>" + shiftdate + "</div>";
              }
              else if(shiftColor == "")
              {
                shiftColor = "red";
                console.log("shiftColorinelse", shiftColor);
                divcontent += "<div class='empdiv' style='border-top: 3px solid " + shiftColor + "; border-bottom: 3px solid " + shiftColor + "; border-left: 10px solid " + shiftColor + "; border-right: 3px solid " + shiftColor + ";' carer_id='" + searchResult[sp].carer_id + "' client_id='" + searchResult[sp].client_id + "' carer_name='" + searchResult[sp].EmpName + "' shift_name='" + searchResult[sp].shift + "' shift_id = '" + searchResult[sp].shiftid + "' client_name='" + searchResult[sp].client + "' start_date='" + searchResult[sp].schstartdt + "' end_date='" + searchResult[sp].schenddt + "' recid='" + searchResult[sp].rec_id + "' shiftstarttime='" + searchResult[sp].shiftstarttime + "' shiftendtime='" + searchResult[sp].shiftendtime + "' shifttype='" + searchResult[sp].shifttype + "' endday='" + searchResult[sp].endday + "'>" + shiftname + "<br>" + shiftdate + "</div>";
              }
            }
          }  
        }
        else if (FilterType=="carercarefaci")
        {
          const searchResult = searchRecord_With_Filter(shiftDataArr,carerName,clientName,carefaciName,DateCurrent);
          if (searchResult.length>0)
          {
            outsideResult=1;
            for (let sp = 0; sp < searchResult.length; sp++)
            {
              const ShiftName = searchResult[sp].concat_shift_name;
              var splitParts = ShiftName.split(/\[|\]/);
              var shiftname = splitParts[0].trim();
              var shiftdate = splitParts[1].trim();
              var shiftColor = searchResult[sp].Card_Color;
              if (shiftColor != "")
              {
                console.log("shiftColorinif", shiftColor);
                divcontent += "<div class='empdiv' style='border-top: 3px solid " + shiftColor + "; border-bottom: 3px solid " + shiftColor + "; border-left: 10px solid " + shiftColor + "; border-right: 3px solid " + shiftColor + ";' carer_id='" + searchResult[sp].carer_id + "' client_id='" + searchResult[sp].client_id + "' carer_name='" + searchResult[sp].EmpName + "' shift_name='" + searchResult[sp].shift + "' shift_id='" + searchResult[sp].shiftid + "' client_name='" + searchResult[sp].client + "' start_date='" + searchResult[sp].schstartdt + "' end_date='" + searchResult[sp].schenddt + "' recid='" + searchResult[sp].rec_id + "' shiftstarttime='" + searchResult[sp].shiftstarttime + "' shiftendtime='" + searchResult[sp].shiftendtime + "' shifttype='" + searchResult[sp].shifttype + "' endday='" + searchResult[sp].endday + "'>" + shiftname + "<br>" + shiftdate + "</div>";
              }
              else if(shiftColor == "")
              {
                shiftColor = "red";
                console.log("shiftColorinelse", shiftColor);
                divcontent += "<div class='empdiv' style='border-top: 3px solid " + shiftColor + "; border-bottom: 3px solid " + shiftColor + "; border-left: 10px solid " + shiftColor + "; border-right: 3px solid " + shiftColor + ";' carer_id='" + searchResult[sp].carer_id + "' client_id='" + searchResult[sp].client_id + "' carer_name='" + searchResult[sp].EmpName + "' shift_name='" + searchResult[sp].shift + "' shift_id = '" + searchResult[sp].shiftid + "' client_name='" + searchResult[sp].client + "' start_date='" + searchResult[sp].schstartdt + "' end_date='" + searchResult[sp].schenddt + "' recid='" + searchResult[sp].rec_id + "' shiftstarttime='" + searchResult[sp].shiftstarttime + "' shiftendtime='" + searchResult[sp].shiftendtime + "' shifttype='" + searchResult[sp].shifttype + "' endday='" + searchResult[sp].endday + "'>" + shiftname + "<br>" + shiftdate + "</div>";
              }
            }
          }  
        }
        else if (FilterType=="clientcarer")
        {
          const searchResult = searchRecord_With_Filter(shiftDataArr,carerName,clientName,0,DateCurrent);
          if (searchResult.length>0)
          {
            outsideResult=1;
            for (let sp = 0; sp < searchResult.length; sp++)
            {
              const ShiftName = searchResult[sp].concat_shift_name;
              var splitParts = ShiftName.split(/\[|\]/);
              var shiftname = splitParts[0].trim();
              var shiftdate = splitParts[1].trim();
              var shiftColor = searchResult[sp].Card_Color;
              if (shiftColor != "")
              {
                console.log("shiftColorinif", shiftColor);
                divcontent += "<div class='empdiv' style='border-top: 3px solid " + shiftColor + "; border-bottom: 3px solid " + shiftColor + "; border-left: 10px solid " + shiftColor + "; border-right: 3px solid " + shiftColor + ";' carer_id='" + searchResult[sp].carer_id + "' client_id='" + searchResult[sp].client_id + "' carer_name='" + searchResult[sp].EmpName + "' shift_name='" + searchResult[sp].shift + "' shift_id='" + searchResult[sp].shiftid + "' client_name='" + searchResult[sp].client + "' start_date='" + searchResult[sp].schstartdt + "' end_date='" + searchResult[sp].schenddt + "' recid='" + searchResult[sp].rec_id + "' shiftstarttime='" + searchResult[sp].shiftstarttime + "' shiftendtime='" + searchResult[sp].shiftendtime + "' shifttype='" + searchResult[sp].shifttype + "' endday='" + searchResult[sp].endday + "'>" + shiftname + "<br>" + shiftdate + "</div>";
              }
              else if(shiftColor == "")
              {
                shiftColor = "red";
                console.log("shiftColorinelse", shiftColor);
                divcontent += "<div class='empdiv' style='border-top: 3px solid " + shiftColor + "; border-bottom: 3px solid " + shiftColor + "; border-left: 10px solid " + shiftColor + "; border-right: 3px solid " + shiftColor + ";' carer_id='" + searchResult[sp].carer_id + "' client_id='" + searchResult[sp].client_id + "' carer_name='" + searchResult[sp].EmpName + "' shift_name='" + searchResult[sp].shift + "' shift_id = '" + searchResult[sp].shiftid + "' client_name='" + searchResult[sp].client + "' start_date='" + searchResult[sp].schstartdt + "' end_date='" + searchResult[sp].schenddt + "' recid='" + searchResult[sp].rec_id + "' shiftstarttime='" + searchResult[sp].shiftstarttime + "' shiftendtime='" + searchResult[sp].shiftendtime + "' shifttype='" + searchResult[sp].shifttype + "' endday='" + searchResult[sp].endday + "'>" + shiftname + "<br>" + shiftdate + "</div>";
              }
            }
          }  
        }
        else if (FilterType=="carer")
        {
          const searchResult = searchRecord_With_Filter(shiftDataArr,carerName,0,0,DateCurrent);
          if (searchResult.length>0)
          {
            outsideResult=1;
            for (let sp = 0; sp < searchResult.length; sp++)
            {
              const ShiftName = searchResult[sp].concat_shift_name;
              var splitParts = ShiftName.split(/\[|\]/);
              var shiftname = splitParts[0].trim();
              var shiftdate = splitParts[1].trim();
              var shiftColor = searchResult[sp].Card_Color;
              if (shiftColor != "")
              {
                console.log("shiftColorinif", shiftColor);
                divcontent += "<div class='empdiv' style='border-top: 3px solid " + shiftColor + "; border-bottom: 3px solid " + shiftColor + "; border-left: 10px solid " + shiftColor + "; border-right: 3px solid " + shiftColor + ";' carer_id='" + searchResult[sp].carer_id + "' client_id='" + searchResult[sp].client_id + "' carer_name='" + searchResult[sp].EmpName + "' shift_name='" + searchResult[sp].shift + "' shift_id='" + searchResult[sp].shiftid + "' client_name='" + searchResult[sp].client + "' start_date='" + searchResult[sp].schstartdt + "' end_date='" + searchResult[sp].schenddt + "' recid='" + searchResult[sp].rec_id + "' shiftstarttime='" + searchResult[sp].shiftstarttime + "' shiftendtime='" + searchResult[sp].shiftendtime + "' shifttype='" + searchResult[sp].shifttype + "' endday='" + searchResult[sp].endday + "'>" + shiftname + "<br>" + shiftdate + "</div>";
              }
              else if(shiftColor == "")
              {
                shiftColor = "red";
                console.log("shiftColorinelse", shiftColor);
                divcontent += "<div class='empdiv' style='border-top: 3px solid " + shiftColor + "; border-bottom: 3px solid " + shiftColor + "; border-left: 10px solid " + shiftColor + "; border-right: 3px solid " + shiftColor + ";' carer_id='" + searchResult[sp].carer_id + "' client_id='" + searchResult[sp].client_id + "' carer_name='" + searchResult[sp].EmpName + "' shift_name='" + searchResult[sp].shift + "' shift_id = '" + searchResult[sp].shiftid + "' client_name='" + searchResult[sp].client + "' start_date='" + searchResult[sp].schstartdt + "' end_date='" + searchResult[sp].schenddt + "' recid='" + searchResult[sp].rec_id + "' shiftstarttime='" + searchResult[sp].shiftstarttime + "' shiftendtime='" + searchResult[sp].shiftendtime + "' shifttype='" + searchResult[sp].shifttype + "' endday='" + searchResult[sp].endday + "'>" + shiftname + "<br>" + shiftdate + "</div>";
              }
            }
          }  
        }
        else if (FilterType=="client")
        {
          const searchResult = searchRecord_With_Filter(shiftDataArr,carerName,clientName,0,DateCurrent);
          if (searchResult.length>0)
          {
            outsideResult=1;
            for (let sp = 0; sp < searchResult.length; sp++)
            {
              const ShiftName = searchResult[sp].concat_shift_name;
              var splitParts = ShiftName.split(/\[|\]/);
              var shiftname = splitParts[0].trim();
              var shiftdate = splitParts[1].trim();
              var shiftColor = searchResult[sp].Card_Color;
              if (shiftColor != "")
              {
                console.log("shiftColorinif", shiftColor);
                divcontent += "<div class='empdiv' style='border-top: 3px solid " + shiftColor + "; border-bottom: 3px solid " + shiftColor + "; border-left: 10px solid " + shiftColor + "; border-right: 3px solid " + shiftColor + ";' carer_id='" + searchResult[sp].carer_id + "' client_id='" + searchResult[sp].client_id + "' carer_name='" + searchResult[sp].EmpName + "' shift_name='" + searchResult[sp].shift + "' shift_id='" + searchResult[sp].shiftid + "' client_name='" + searchResult[sp].client + "' start_date='" + searchResult[sp].schstartdt + "' end_date='" + searchResult[sp].schenddt + "' recid='" + searchResult[sp].rec_id + "' shiftstarttime='" + searchResult[sp].shiftstarttime + "' shiftendtime='" + searchResult[sp].shiftendtime + "' shifttype='" + searchResult[sp].shifttype + "' endday='" + searchResult[sp].endday + "'>" + shiftname + "<br>" + shiftdate + "</div>";
              }
              else if(shiftColor == "")
              {
                shiftColor = "red";
                console.log("shiftColorinelse", shiftColor);
                divcontent += "<div class='empdiv' style='border-top: 3px solid " + shiftColor + "; border-bottom: 3px solid " + shiftColor + "; border-left: 10px solid " + shiftColor + "; border-right: 3px solid " + shiftColor + ";' carer_id='" + searchResult[sp].carer_id + "' client_id='" + searchResult[sp].client_id + "' carer_name='" + searchResult[sp].EmpName + "' shift_name='" + searchResult[sp].shift + "' shift_id = '" + searchResult[sp].shiftid + "' client_name='" + searchResult[sp].client + "' start_date='" + searchResult[sp].schstartdt + "' end_date='" + searchResult[sp].schenddt + "' recid='" + searchResult[sp].rec_id + "' shiftstarttime='" + searchResult[sp].shiftstarttime + "' shiftendtime='" + searchResult[sp].shiftendtime + "' shifttype='" + searchResult[sp].shifttype + "' endday='" + searchResult[sp].endday + "'>" + shiftname + "<br>" + shiftdate + "</div>";
              }
            }
          }
        }
        else if (FilterType=="careFaci")
        {
          const searchResult = searchRecord_With_Filter(shiftDataArr,carerName,clientName,carefaciName,DateCurrent);
          if (searchResult.length>0)
          {
            outsideResult=1;
            for (let sp = 0; sp < searchResult.length; sp++)
            {
              const ShiftName = searchResult[sp].concat_shift_name;
              var splitParts = ShiftName.split(/\[|\]/);
              var shiftname = splitParts[0].trim();
              var shiftdate = splitParts[1].trim();
              var shiftColor = searchResult[sp].Card_Color;
              if (shiftColor != "")
              {
                console.log("shiftColorinif", shiftColor);
                divcontent += "<div class='empdiv' style='border-top: 3px solid " + shiftColor + "; border-bottom: 3px solid " + shiftColor + "; border-left: 10px solid " + shiftColor + "; border-right: 3px solid " + shiftColor + ";' carer_id='" + searchResult[sp].carer_id + "' client_id='" + searchResult[sp].client_id + "' carer_name='" + searchResult[sp].EmpName + "' shift_name='" + searchResult[sp].shift + "' shift_id='" + searchResult[sp].shiftid + "' client_name='" + searchResult[sp].client + "' start_date='" + searchResult[sp].schstartdt + "' end_date='" + searchResult[sp].schenddt + "' recid='" + searchResult[sp].rec_id + "' shiftstarttime='" + searchResult[sp].shiftstarttime + "' shiftendtime='" + searchResult[sp].shiftendtime + "' shifttype='" + searchResult[sp].shifttype + "' endday='" + searchResult[sp].endday + "'>" + shiftname + "<br>" + shiftdate + "</div>";
              }
              else if(shiftColor == "")
              {
                shiftColor = "red";
                console.log("shiftColorinelse", shiftColor);
                divcontent += "<div class='empdiv' style='border-top: 3px solid " + shiftColor + "; border-bottom: 3px solid " + shiftColor + "; border-left: 10px solid " + shiftColor + "; border-right: 3px solid " + shiftColor + ";' carer_id='" + searchResult[sp].carer_id + "' client_id='" + searchResult[sp].client_id + "' carer_name='" + searchResult[sp].EmpName + "' shift_name='" + searchResult[sp].shift + "' shift_id = '" + searchResult[sp].shiftid + "' client_name='" + searchResult[sp].client + "' start_date='" + searchResult[sp].schstartdt + "' end_date='" + searchResult[sp].schenddt + "' recid='" + searchResult[sp].rec_id + "' shiftstarttime='" + searchResult[sp].shiftstarttime + "' shiftendtime='" + searchResult[sp].shiftendtime + "' shifttype='" + searchResult[sp].shifttype + "' endday='" + searchResult[sp].endday + "'>" + shiftname + "<br>" + shiftdate + "</div>";
              }
            }
          }
        }
      });
      if (outsideResult==0)
      {
        bodyhtml+="<td class='empbtn' currentdate='"+DateCurrent+"'>+</td>";
      }
      else
      {
        divcontent+="<div class='empbtn' currentdate='"+DateCurrent+"'>+</div>";
        bodyhtml+="<td>"+divcontent+"</td>";
      }
    });
    $('#datesBody').append("<tr>"+bodyhtml+"</tr>");
    var imgData="#img-"+carerID;
    let imgTag = document.querySelector(imgData);
    var imageFromGetRecordsAPI=imgTag.getAttribute("orginimage");
    if (imageFromGetRecordsAPI!="") {
      ZOHO.CREATOR.UTIL.setImageData(imgTag, zohoImage);
    }
    // else
    // {
    //   const defaultImage="/api/v2/homecaredirect/hcd-admin/report/Clients_Profile_Images_Report/134556000002408039/Clients_Image_test/download?filepath=1712662542081_240_F_65772719_A1UV5kLi5nCEWI0BNLLiFaBPEkUbv5Fv.jpg";
    //   ZOHO.CREATOR.UTIL.setImageData(imgTag, defaultImage);
    // }
  });
}


$(document).on("click",".imageAppend", function () { //testing function
  console.log("imageAppend button clicked");
  $("#datesBody tr").each(function(){
    console.log("Each function working");
    var carerid=$(this).find(".emp_td").attr("carerid");
    var zohoImage=$(this).find(".emp_td").attr("orginimage");
    var imgData="#img-"+carerid;
    let imgTag = document.querySelector(imgData);
    var imageFromGetRecordsAPI=imgTag.getAttribute("orginimage");
    if (imageFromGetRecordsAPI!="") {
      // Assuming product.Image is the image URL
      ZOHO.CREATOR.UTIL.setImageData(imgTag, zohoImage);
    }
  });
});
// Function to handle date selection and display corresponding week
$(document).on('change', '#selectedDate', function() {
  const selectedDate = new Date($(this).val()); // Get selected date from input field
 
  // Calculate the start and end of the week containing the selected date
  const selectedDayOfWeek = selectedDate.getDay(); // Day of the week (0 = Sunday, 1 = Monday, ..., 6 = Saturday)
  let startDate = new Date(selectedDate);

  // Adjust the start date if the selected day is not Monday (1)
  if (selectedDayOfWeek !== 1) {
    const difference = selectedDayOfWeek === 0 ? 6 : selectedDayOfWeek - 1; // Calculate the difference between Sunday (0) and the selected day
    startDate.setDate(selectedDate.getDate() - difference); // Start of the week (Monday)
  }

  const endDate = new Date(startDate);
  endDate.setDate(startDate.getDate() + 6); // End of the week (Sunday)

  console.log("StartDate:", startDate);
  console.log("EndDate:", endDate);

  // Update currentWeek object and display week details
  currentWeek = { startDate, endDate };
  displayWeekDetails(startDate, endDate);
    $("#current_btns_details").css("display", "block");
});
 
// Initial setup to display current week on page load
function initializeCalendar() {
  // Get current week details and display
  currentWeek = getCurrentWeekDetails();
  displayWeekDetails(currentWeek.startDate, currentWeek.endDate);
}
 
// Call initializeCalendar function on page load
initializeCalendar();