$(document).delegate('.btn-sve', 'click', function(){
  $(".btn-sve").attr("disabled",true);
  var mainform_ID = $("#Emp_recid").val() || 0;
  var client_id = $("#dropdownname_cl_popup option:selected").attr("cl_rec_id");                                                                            
  var carer_id =  $("#dropdownname_cr_popup option:selected").attr("cr_rec_id");
  var Shift_start = $("#st_date_emp").val();
  var Shift_end =  $("#ed_date_emp").val();
  var Shift_Start_Time = $("#st_time_emp").val();
  var Shift_End_Time = $("#ed_time_emp").val();
  var Shift_id =  $("#dropdownname_sht option:selected").attr("shift_rec_id");
  var EnddayEndDay_shift_for =  $("#dropdownname_EndDay_shift_popup option:selected").val();
  var new_shift_singleline = $("#singleline_sht").val();
  var shift_type = $(".shift_type_checkbox1:checked").val();
  console.log("shift_type:",shift_type);
  if (new_shift_singleline != '' && mainform_ID !=0)
  {
      shiftformDataupdate = {
      "data" : {
      "Clients":client_id,
      "Carers": carer_id,
      "Shift_Start_Date":moment(Shift_start).format("DD-MMM-YYYY"),
      "Shift_Name":new_shift_singleline,
      "Shift_Start_Time": Shift_Start_Time,
      "Shift_End_Time": Shift_End_Time,
      "End_Day":EnddayEndDay_shift_for,
      "Shift_Type":shift_type,
      "Shift_Status":"Open"
      }
    }
    var shiftconfigupdate = {    
      appName : "hcd-admin",
      formName : "Shift",
      data : shiftformDataupdate
    }
    ZOHO.CREATOR.API.addRecord(shiftconfigupdate).then(function (shiftresponseupdate) {
      console.log("shiftresponseupdate",shiftresponseupdate.data)
      var Shift_idid_update = shiftresponseupdate.data.ID;
          if(Shift_idid_update.code == 3000){
          console.log("Record added successfully");
      }  
      formDataupdate = {
        "data" : {
          "ID":mainform_ID,
          "Clients": client_id,
          "Shift": Shift_idid_update,
          "Scheduled_Start_Date":moment(Shift_start).format("DD-MMM-YYYY"),
          "Scheduled_End_Date":moment(Shift_end).format("DD-MMM-YYYY"),
          "Scheduled_Start_Time":Shift_Start_Time,
          "Scheduled_End_Time":Shift_End_Time
        }
      };
      console.log("formDataupdate:",formDataupdate);
      var shiftconfigupdate = {    
        appName : "hcd-admin",
        reportName : "Shift_Report",
        id : mainform_ID,
        data : shiftformDataupdate
      }
    //  console.log("shiftconfigupdate", shiftconfigupdate);
      ZOHO.CREATOR.API.updateRecord(shiftconfigupdate).then(function (responseupdaterecord) {
              
            console.log("responseupdaterecord:",responseupdaterecord);
          var Shift_assign_update = responseupdaterecord.data.ID;
          
          if(responseupdaterecord.code == 3000){
            $("#exampleModal").modal("hide");
            shiftDataArr=[];
            VisitSchedule_Func().then(ReturnVal=>{
              DisplayShiftDetails_Func();
            });
            console.log("Record added successfully");
            Swal.fire({
              title: "Record Updated successfully",
              icon: "success",
              showConfirmButton :false,
              timer: 1000
            });
          }
          else
          {
            Swal.fire({
              title: "Record not Updated successfully",
              icon: "error",
              showConfirmButton :false,
              timer: 1000
            });
          }
          $(".btn-sve").prop("disabled",false);
      });
    });
  }
  else if(new_shift_singleline != '' && mainform_ID ==0)
  {
    shiftformData = {
      "data" : {
      "Clients":client_id,
      "Carers": carer_id,
      "Shift_Start_Date":moment(Shift_start).format("DD-MMM-YYYY"),
      "Shift_Name":new_shift_singleline,
      "Shift_Start_Time": Shift_Start_Time,
      "Shift_End_Time": Shift_End_Time,
      "End_Day":EnddayEndDay_shift_for,
      "Shift_Type":shift_type,
      "Shift_Status":"Open"
      }
    }
    var shiftconfig = {    
      appName : "hcd-admin",
      formName : "Shift",
      data : shiftformData
      }
      ZOHO.CREATOR.API.addRecord(shiftconfig).then(function(shiftresponse){
        var Shift_idid = shiftresponse.data.ID;
        // shiftidid.push(Shift_idid);
        if(shiftresponse.code == 3000){
          console.log("Record added successfully");
        }
        // var lineItems =[];
        // var lineItem = {Clients:client_id,Shift:Shift_idid,button_purpose:"In",Numshift:1,Scheduled_Start_Date:moment(Shift_start).format("DD-MMM-YYYY"),Scheduled_End_Date:moment(Shift_end).format("DD-MMM-YYYY"),Scheduled_Start_Time:Shift_Start_Time,Scheduled_End_Time:Shift_End_Time};
        // lineItems.push(lineItem);
        newshiftformData = {
          "data" : {
            "Carers": carer_id,
            "Start_Date":moment(Shift_start).format("DD-MMM-YYYY"),
            "End_Date":moment(Shift_end).format("DD-MMM-YYYY"),
            "Clients":client_id,
            "Shift":Shift_idid,
            "Scheduled_Start_Date":moment(Shift_start).format("DD-MMM-YYYY"),
            "Scheduled_End_Date":moment(Shift_end).format("DD-MMM-YYYY"),
            "Scheduled_Start_Time":Shift_Start_Time,
            "Scheduled_End_Time":Shift_End_Time
          }
        }
        // console.log("newshiftformData:",newshiftformData);
        var newshiftconfig = {    
          appName : "hcd-admin",
          formName : "Employee_Shift",
          data : newshiftformData
          }
        ZOHO.CREATOR.API.addRecord(newshiftconfig).then(function(newshiftresponse){
          console.log("newshiftresponse:",newshiftresponse);
          if(newshiftresponse.code == 3000){
            $("#exampleModal").modal("hide");
            shiftDataArr=[];
            VisitSchedule_Func().then(ReturnVal=>{
              DisplayShiftDetails_Func();
            });
            Swal.fire({
              title: "Record added successfully",
              icon: "success",
              showConfirmButton :false,
              timer: 1000
            });
          }
          else
          {
            Swal.fire({
              title: "Record not added successfully",
              icon: "error",
              showConfirmButton :false,
              timer: 1000
            });
          }
          $(".btn-sve").prop("disabled",false);
        });
    });
  }
  else if (mainform_ID !=0 && new_shift_singleline == '')
  {
    formData = {
      "data" : {
      "Clients":client_id,
      "Shift": Shift_id,
      "Carers": carer_id,
      "Start_Date":moment(Shift_start).format("DD-MMM-YYYY"),
        // "Numshift": 1,
        // "button_purpose":"In",
        "Scheduled_Start_Date":moment(Shift_start).format("DD-MMM-YYYY"),
        "Scheduled_End_Date":moment(Shift_end).format("DD-MMM-YYYY"),
        "Scheduled_Start_Time":Shift_Start_Time,
        "Scheduled_End_Time":Shift_End_Time,
      }
    };
 
    var shiftconfigupdate = {    
      appName : "hcd-admin",
      reportName : "Shift_Report",
      id : mainform_ID,
      data : formData
    }
    ZOHO.CREATOR.API.updateRecord(shiftconfigupdate).then(function(responseupdaterecord){
      console.log("responseupdaterecord:",responseupdaterecord);
      var Shift_assign_update = responseupdaterecord.data.ID;
       
        if(responseupdaterecord.code == 3000){
          console.log("Record added successfully");
          $("#exampleModal").modal("hide");
          shiftDataArr=[];
          VisitSchedule_Func().then(ReturnVal=>{
            DisplayShiftDetails_Func();
          });
          Swal.fire({
            title: "Record Updated successfully",
            icon: "success",
            showConfirmButton :false,
            timer: 1000
          });
        }
        else
        {
          Swal.fire({
            title: "Record not Updated successfully",
            icon: "error",
            showConfirmButton :false,
            timer: 1000
          });
        }
        $(".btn-sve").prop("disabled",false);
    });
  }
  else if (mainform_ID ==0 && new_shift_singleline == '')
  {
    formData = {
      "data" : {
      "Clients":client_id,
      "Shift": Shift_id,
      "Carers": carer_id,
      "Start_Date":moment(Shift_start).format("DD-MMM-YYYY"),
        // "Numshift": 1,
        // "button_purpose":"In",
        "Scheduled_Start_Date":moment(Shift_start).format("DD-MMM-YYYY"),
        "Scheduled_End_Date":moment(Shift_end).format("DD-MMM-YYYY"),
        "Scheduled_Start_Time":Shift_Start_Time,
        "Scheduled_End_Time":Shift_End_Time,
      }
    };
 
    var shiftconfigupdate = {    
      appName : "hcd-admin",
      formName : "Employee_Shift",
      data : formData
    }
    ZOHO.CREATOR.API.addRecord(shiftconfigupdate).then(function(responseupdaterecord){
      console.log("responseupdaterecord:",responseupdaterecord);
      var Shift_assign_update = responseupdaterecord.data.ID;
       
        if(responseupdaterecord.code == 3000){
          console.log("Record added successfully");
          $("#exampleModal").modal("hide");
          shiftDataArr=[];
          VisitSchedule_Func().then(ReturnVal=>{
            DisplayShiftDetails_Func();
          });
          
          Swal.fire({
            title: "Record added successfully",
            icon: "success",
            showConfirmButton :false,
            timer: 1000
          });
        }
        else
        {
          Swal.fire({
            title: "Record not Updated successfully",
            icon: "error",
            showConfirmButton :false,
            timer: 1000
          });
        }
        $(".btn-sve").prop("disabled",false);
    });
  }
});

$(document).delegate('.del_btn', 'click', function(){
  var mainform_ID = $("#Emp_recid").val() || 0;
  $(".del_btn").attr("disabled",true);
  console.log("Hi i'm dlt btn");
  var config_delete = { 
    appName : "hcd-admin",
    reportName : "Shift_Report",
    criteria : '(ID == '+mainform_ID+')'
  } 
  ZOHO.CREATOR.API.deleteRecord(config_delete).then(function(response_delete){
      console.log("Record has been deleted");

      if(response_delete.code == 3000){
        console.log("Record deleted successfully");
        $("#exampleModal").modal("hide");
        shiftDataArr=[];
        VisitSchedule_Func().then(ReturnVal=>{
          DisplayShiftDetails_Func();
        });
        Swal.fire({
          title: "Record Deleted successfully",
          icon: "success",
          showConfirmButton :false,
          timer: 1500
        });
      }
      else
      {
        Swal.fire({
          title: "Error Occurred While Deleting Records...!",
          icon: "error",
          showConfirmButton :false,
          timer: 1500
        });
      }
      $(".del_btn").attr("disabled",false);
  });
  $(".del_btn").attr("disabled",true); 
});




