$(document).delegate('.add_shift', 'click', function(){
  $('#dropdownname_sht').css("display", "none");
  $('#singleline_sht').css("display", "block");
  $('#singleline_sht').val('');
  $('.add_shift').css("display", "none");
  $('.remove_shift').css("display", "block");
  $('#st_time_emp').val('');
  $('#ed_time_emp').val('');
  $('#dropdownname_EndDay_shift_popup').val('');
  $(".check_sameday").prop("checked", false);
  $(".check_multiday").prop("checked", false);
});
$(document).delegate('.remove_shift', 'click', function(){
  $('#dropdownname_sht').css("display", "block");
  $('#dropdownname_sht').css("margin-left", "8px");
  $('#singleline_sht').css("display", "none");
  $('.add_shift').css("display", "block");
  $('.remove_shift').css("display", "none");
  $('#dropdownname_sht').val('');
  $('#st_time_emp').val('');
  $('#ed_time_emp').val('');
  $('#dropdownname_EndDay_shift_popup').val('');
  $(".check_sameday").prop("checked", false);
  $(".check_multiday").prop("checked", false);
 
});
$(document).delegate('.close', 'click', function () {
 
  var popup = document.querySelector('.overlay');
  popup.style.display = 'none';
});

var popupCarerID=0;
var popupClientID=0;
var popupShiftiD=0;

$(document).delegate('.empdiv', 'click', function () {

  $(".btn-sve span").text("Update");
  $(".del_btn").attr("disabled",false);
  $('#dropdownname_cr_popup').find("option:not(:first)").remove();
  $("#dropdownname_cl_popup").find("option:not(:first)").remove();
  var rowData=$(this).closest("tr");
  var carerName=rowData.find(".emp_td").text();
  var carerID=rowData.find(".emp_td").attr("carerID");

  $('#dropdownname_cr_popup').append($('<option>', {
    value: carerID,
    text: carerName,
    "cr_rec_id":carerID,
    selected: true
  }));

  var client_id = this.getAttribute("client_id");
  var shift_id = this.getAttribute("shift_id");

  popupCarerID=carerID;
  popupClientID=client_id;
  popupShiftiD=shift_id;

  const ClientFiltered_Data = wholeCareClient.filter(item => item.carerName === carerName);
  if (ClientFiltered_Data.length>0)
  {
    ClientFiltered_Data.forEach(cliElement=>{
      if (cliElement.clientID ==client_id)
      {
        $('#dropdownname_cl_popup').append($('<option>', {
          value: cliElement.clientID,
          text: cliElement.clientName,
          "cl_rec_id":cliElement.clientID,
          selected: true
        }));
      }
      else
      {
        $('#dropdownname_cl_popup').append($('<option>', {
          value: cliElement.clientID,
          text: cliElement.clientName
        }));
      }
    });
    // $('#dropdownname_cl_popup').trigger("change",[carerID,client_id,shift_id]);
    $('#dropdownname_cl_popup').trigger("change");
  }

  var carer_id = this.getAttribute("carer_id");
  var carer_name= this.getAttribute("carer_name");
  var client_name= this.getAttribute("client_name");
  var shift_name= this.getAttribute("shift_name");
  var start_date= this.getAttribute("start_date");
  var end_date= this.getAttribute("end_date");
  var recid= this.getAttribute("recid");
  var shiftstarttime= this.getAttribute("shiftstarttime");
  var shiftendtime= this.getAttribute("shiftendtime");
  var shifttype= this.getAttribute("shifttype");
  var endday = this.getAttribute("endday");
  $('#st_date_emp').val( moment(start_date).format("YYYY-MM-DD"));
  $('#ed_date_emp').val(moment(end_date).format("YYYY-MM-DD"));
  $(".dropdownname_EndDay_shift_popup").val(endday);
  if(shifttype == "Same day")
  {
    $(".check_sameday").prop("checked", true);
    $(".check_multiday").prop("checked", false);
  }
  else if(shifttype == "Multi day")
  {
    $(".check_multiday").prop("checked", true);
    $(".check_sameday").prop("checked", false);
  
  }
  else{
    $(".check_sameday").prop("checked", false);
    $(".check_multiday").prop("checked", false);
  }
  $('#st_time_emp').val(shiftstarttime);
  $('#ed_time_emp').val(shiftendtime);
  var Emp_Recid = this.getAttribute("recid");
  $('#Emp_recid').val(Emp_Recid);
  $("#exampleModal").modal('show');
  
});

$(document).delegate('.empbtn', 'click', function () {
  $(".btn-sve span").text("Save");
  $(".del_btn").attr("disabled",true);
  $('#dropdownname_sht').css("margin-left", "8px");
  $('#dropdownname_cr_popup').find("option:not(:first)").remove();
  $("#dropdownname_cl_popup").find("option:not(:first)").remove();
  $("#Emp_recid").val('');
  var rowData=$(this).closest("tr");
  var carerName=rowData.find(".emp_td").text();
  var carerID=rowData.find(".emp_td").attr("carerID");

  var currentDate=$(this).attr("currentdate");

  popupCarerID=carerID;

  $('#dropdownname_cr_popup').append($('<option>', {
    value: carerID,
    text: carerName,
    "cr_rec_id":carerID,
    selected: true
  }));

  const ClientFiltered_Data = wholeCareClient.filter(item => item.carerName === carerName);
  if (ClientFiltered_Data.length>0)
  {
    ClientFiltered_Data.forEach(cliElement=>{
      $('#dropdownname_cl_popup').append($('<option>', {
        value: cliElement.clientID,
        text: cliElement.clientName,
        "cl_rec_id":cliElement.clientID,
        selected: false
      }));
    });
  }
  $("#dropdownname_sht").find("option:not(:first)").remove();
  $('#st_date_emp').val( moment(currentDate).format("YYYY-MM-DD"));
  $('#ed_date_emp').val(moment(currentDate).format("YYYY-MM-DD"));
  var shiftname= this.getAttribute("shift_name");
  $("#singleline_sht").val('');
  $("#singleline_sht").css("display", "none");
  $('#dropdownname_sht').css("display", "block");
  $('.add_shift').css("display", "block");
  $('.remove_shift').css("display", "none");
  var shiftstarttime = this.getAttribute("shiftstarttime");
  var shiftendtime = this.getAttribute("shiftendtime");
  var shifttype = this.getAttribute("shifttype");
  var endday = this.getAttribute("endday");
  $(".dropdownname_EndDay_shift_popup").val(endday);
  if(shifttype == "Same day")
  {
    $(".check_sameday").prop("checked", true);
    $(".check_multiday").prop("checked", false);
  }
  else if(shifttype == "Multi day")
  {
    $(".check_multiday").prop("checked", true);
    $(".check_sameday").prop("checked", false);
  
  }
  else{
    $(".check_sameday").prop("checked", false);
    $(".check_multiday").prop("checked", false);
  }
  $('#st_time_emp').val(shiftstarttime);
  $('#ed_time_emp').val(shiftendtime);
  $("#exampleModal").modal('show');


});

$(document).on("change", "#dropdownname_cl_popup", function(){
  $("#dropdownname_sht").find("option:not(:first)").remove();

  var carer_id_check=popupCarerID;
  var client_id_check=$(this).find("option:selected").val() || 0;
  var shift_id_check=popupShiftiD;

  popupClientID=0;
  popupShiftiD=0;
  if (client_id_check != 0 && carer_id_check != 0)
  {
    GetShiftDetails_Func(client_id_check).then(shiftResult=>{ //ZohoApi.js
      if (shiftResult.length>0)
      {
        shiftResult.forEach(shiftList=>{
          if (shiftList.shiftID == shift_id_check)
          {
            $('#dropdownname_sht').append($('<option>', {
              value: shiftList.shiftID,
              text: shiftList.shiftName,
              "shift_rec_id":shiftList.shiftID,
              selected: true
            }));
          }
          else
          {
            $('#dropdownname_sht').append($('<option>', {
              value: shiftList.shiftID,
              text: shiftList.shiftName,
              "shift_rec_id":shiftList.shiftID
            }));
          }
        });
        $("#dropdownname_sht").trigger("change",["true"]);
      }
      else
      {
        // alert("No shift found");
        Swal.fire({
          title: "Shifts are closed / No Shift Found",
          icon: "warning",
          showConfirmButton :false,
          timer: 2000
        });
      }
    });
  }
});

var existingStartTime=0;
var existingEndTime=0;
$(document).on("change","#dropdownname_sht", function(event,params){
  var defaultTrigger=params||0;
  var SelectedShiftID=$(this).find("option:selected").val() ||0;
  existingStartTime=$('#st_time_emp').val() ||0;
  existingEndTime=$('#ed_time_emp').val() ||0;

  if (SelectedShiftID!=0)
  {
    ZOHO.CREATOR.API.getRecordById({
      reportName : "Shift_Report1", 
      id:SelectedShiftID
      }).then(function(singleShift){
      if (singleShift.code==3000)
      {
        var shiftData=singleShift.data;
        var shiftstarttimer = shiftData.Shift_Start_Time;
        var shiftendtimer = shiftData.Shift_End_Time;
        var shifttyprforshift = shiftData.Shift_Type;
        var shiftenddayforshift = shiftData.End_Day;

        $(".dropdownname_EndDay_shift_popup").val(shiftenddayforshift);
        if(shifttyprforshift == "Same day")
        {
          $(".check_sameday").prop("checked", true);
          $(".check_multiday").prop("checked", false);
          $('.shift_type_checkbox').attr('orginalcheckboxvalues',shifttyprforshift);
        }
        else if(shifttyprforshift == "Multi day")
        {
          $(".check_multiday").prop("checked", true);
          $(".check_sameday").prop("checked", false);
          $('.shift_type_checkbox').attr('orginalcheckboxvalues',shifttyprforshift);
        }
        if (defaultTrigger==0) //append start end time on popup
        {
          if (shiftenddayforshift=="Next day")
          {
            var OldEndDate=$("#ed_date_emp").val();
            var NewEndDate=addDaysToDate(OldEndDate, 1);
            $('#ed_date_emp').val(moment(NewEndDate).format("YYYY-MM-DD"));
          }
          else
          {

            $('#ed_date_emp').val(moment($("#st_date_emp").val()).format("YYYY-MM-DD"));
          }
          $('#st_time_emp').val(shiftstarttimer);
          $('#ed_time_emp').val(shiftendtimer);
          existingEndTime=0;
          existingStartTime=0;
        }

        
      }
    });
  }
});

// Function to check or uncheck the checkbox
$(document).on("click",".shift_type_checkbox1",function(){
  // Uncheck all checkboxes
  $('.shift_type_checkbox1').prop('checked', false);
  // Check the clicked checkbox
  $(this).prop('checked', true);
});


