$(document).delegate('.export_btn', 'click', function(){
  console.log("Export");
  var fileConcat=$("#weekDates").text();
  console.log("fileConcat:",fileConcat);
  var fileName="Shift_Allocation "+fileConcat;
  html2canvas(document.getElementById("weekDetails")).then(canvas => {
    const imgData = canvas.toDataURL('image/png');
    const pdf = new window.jspdf.jsPDF();  // Correct access to jsPDF from UMD module
    const imgProps= pdf.getImageProperties(imgData);
    const pdfWidth = pdf.internal.pageSize.getWidth();
    const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width;
    pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight);
    pdf.save(fileName+".pdf");
  });
});
$(document).delegate('.pdf_btn', 'click', function(){
    console.log("pdf");
    window.print();
});