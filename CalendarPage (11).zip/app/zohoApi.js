var wholeCareClient=[];

async function DisplayFilterData_Func(){
  try {
    const carerReport = Carer_Filter_Func(); // Call your first asynchronous function
    const ClientFilterReport = Client_Filter_Func(); // Call your second asynchronous function
    const clientcarerReport = ClientCarer_Filter_Func(); // Call your third asynchronous function
    const VisitScheduleReport = VisitSchedule_Func();


    

    const clientCarer_Result = await Promise.all([clientcarerReport]);
    const CarerResult = await Promise.all([carerReport]);
    const ClientResult = await Promise.all([ClientFilterReport]);
    // console.log("clientCarer_Result:",clientCarer_Result);



    console.log("carerReport:",carerReport);
    console.log("ClientFilterReport:",ClientFilterReport);
    console.log("clientcarerReport:",clientcarerReport);
    
    const uniqueCarerNames = [...new Set(clientCarer_Result[0].map(item => item.carerName))]; // function to extract unique CarerNames 
    console.log("uniqueCarerNames:",uniqueCarerNames);
    // const uniqueClientNames = [...new Set(clientCarer_Result[0].map(item => item.clientName))]; // function to extract unique ClientNames 
    // console.log("uniqueClientNames:",uniqueClientNames);
    const uniqueClientNames = [...new Set(clientCarer_Result[0].map(item => item.clientID))]; // function to extract unique ClientNames 
    console.log("uniqueClientNames:",uniqueClientNames);

    // Function to filter the carer unique data
    function filterData(data, data1) {
      return data.filter(item => data1.includes(item.carerName));
    }
    const filteredData = filterData(CarerResult[0],uniqueCarerNames);
    console.log("filteredData",filteredData);
    for(var index in filteredData){
      var rec_id = filteredData[index].carerID;
      var carerName = filteredData[index].carerName;
      var Care_Facilitators = filteredData[index].care_faci || 0;
      
      $('.carerdataDD').append($('<option>', {
        value: rec_id,
        text: carerName,
        'cr_rec_id':rec_id,  // Example additional attribute
        'carer_name': carerName   // Another example additional attribute
      }));
    }

    // Client function
    function filterClientData(data, data1) {
      return data.filter(item => data1.includes(item.clientID));
    }
    const filteredClientData = filterClientData(ClientResult[0],uniqueClientNames);
    console.log("filteredClientData",filteredClientData);
    for(var index in filteredClientData){
      var rec_id = filteredClientData[index].clientID;
      var clientName = filteredClientData[index].clientName;  
      
      $('.clientdataDD').append($('<option>', {
        value: rec_id,
        text: clientName,
        'cl_rec_id':rec_id,  // Example additional attribute
        'client_name': clientName   // Another example additional attribute
      }));
    }

    // Client Carer Function
    // const uniqueCareFaciNames = [...new Set(clientCarer_Result[0].map(item => item.careFaciName))];
    const uniqueCareFaciNames = clientCarer_Result[0] ? [...new Set(clientCarer_Result[0].map(item => item.careFaciName))].filter(name => name !== "") : [];
    uniqueCareFaciNames.forEach(resultdata=>{
      $('.carefacidataDD').append($('<option>', {
        value: resultdata,
        text: resultdata,
        'care_facilitier_name':resultdata
      }));
    });
    // *****************************************************************************
    
    carerArr=filteredData;  // push data into carerArr
    const result = await Promise.all([VisitScheduleReport]);
    return result;

} catch (error) {
    console.error('Error:', error);
}
}
async function Carer_Filter_Func() {
  var returnVal=null;
  try
  {
    const carer_response = await ZOHO.CREATOR.API.getAllRecords({ 
      appName : "hcd-admin",
      reportName : "Carers_Report", 
      page : 1
    });
    const recordArr = await carer_response.data;
    // console.log("recordArr:",recordArr);
    var CarerList = [];
    for(var index in recordArr){
      var rec_id = recordArr[index].ID;
      var carerName = recordArr[index].Name.display_value;
      var Care_Facilitators = recordArr[index].Care_Facilitier || 0;
      var carer_profile = recordArr[index].Carer_Image;
      // if(carer_profile !=  null)
      // {
      //   var imageTag = document.getElementById("imageTag");
      //   var imageURL = carer_profile;
      //   ZOHO.CREATOR.UTIL.setImageData(imageTag, imageURL);
      // }
      // else
      // {
      //   var imageTag = document.getElementById("imageTag");
      //   var imageURL = "/api/v2/homecaredirect/hcd-admin/report/Clients_Profile_Images_Report/134556000002408039/Clients_Image_test/download?filepath=1712662542081_240_F_65772719_A1UV5kLi5nCEWI0BNLLiFaBPEkUbv5Fv.jpg";
      //   ZOHO.CREATOR.UTIL.setImageData(imageTag, imageURL);
      // }

      CarerList.push({
        "carerID":rec_id,
        "carerName":carerName.trim(),
        "care_faci":Care_Facilitators,
        "Image":carer_profile
      });
    }
    const uniqueArrayvalue = [...new Set(CarerList)];
    // console.log("uniqueArrayvalue:",uniqueArrayvalue);
    returnVal=uniqueArrayvalue;
  }catch (error)
  {
    console.log("error found:",error);
  }
  return returnVal;
}
async function ClientCarer_Filter_Func() {
  var returnVal=null;
  var ClientCarerList=[];
  try{
    const ClientCarer_Response = await ZOHO.CREATOR.API.getAllRecords({ 
      appName : "hcd-admin",
      reportName : "Client_Carers_Report",
      criteria : '(Add_3 == true)',
      page : 1
    });
    const recordArr = await ClientCarer_Response.data;
    console.log("ClientCarer_Response:",recordArr);
    for(var index in recordArr){
      var rec_id = recordArr[index].ID;
      var carerImage=recordArr[index]["Carers.Carer_Image"];
      console.log("carerImage:",carerImage);
      var carerName = recordArr[index].Carers;
      var carerID=null;
      if (carerName)
      {
        carerName = recordArr[index].Carers.display_value || 0;
        carerID=recordArr[index].Carers.ID || 0;
      }
      var ClientName = recordArr[index].Clients;
      var clientID=null;
      if (ClientName)
      {
        ClientName = recordArr[index].Clients.display_value || 0;
        clientID = recordArr[index].Clients.ID || 0;
      }
      ClientName=ClientName.replace(/\s+/g, ' ');

      var careFaciName=recordArr[index]["Carers.Care_Facilitier"];
      ClientCarerList.push({
        "recID":rec_id,
        "careFaciName":careFaciName,
        "carerName":carerName.trim(),
        "carerID":carerID,
        "clientName":ClientName.trim(),
        "clientID":clientID,
        "carerImage":carerImage
      });
    }
    const uniqueArrayvalue = [...new Set(ClientCarerList)];
    wholeCareClient=uniqueArrayvalue;

  }catch(error){
    console.log("error",error);
  }
  console.log("ClientCarerList:",ClientCarerList);
  return ClientCarerList;
}
async function Client_Filter_Func() {
  var clientList=[];
  try
  {
    const clinet_response = await ZOHO.CREATOR.API.getAllRecords({
      reportName : "Clients_Report",  
      page : 1
    });
    const clientrecordArr = await clinet_response.data;
    for(var cliindex in clientrecordArr){
      var recid=clientrecordArr[cliindex].ID;
      clientList.push({
        "clientID":clientrecordArr[cliindex].ID,
        "clientName":clientrecordArr[cliindex].Name.display_value
      });
    }
  }catch (error)
  {
    console.log("error found:",error);
  }
  // console.log("clientList:",clientList);
  return clientList;
}
async function VisitSchedule_Func() {
  var emplist=[];
  for (let i = 1; i <=10; i++)
  {
    var Visitconfig = { 
      appName : "hcd-admin",
      reportName : "Important_of_Visit_Schedules", 
      page : i
    }
    try{
      const cust_response = await ZOHO.CREATOR.API.getAllRecords(Visitconfig);
      const recordArr = await cust_response.data;
      // console.log("recordArr visit:",recordArr);
      for(var index in recordArr){
        var rec_id = recordArr[index].ID;
        var start_date = recordArr[index].Start_Date;
        var end_date = recordArr[index].End_Date;
        var carer = recordArr[index].Carers.display_value.trim();
        var carer_id = recordArr[index].Carers.ID.trim();
        var care_facilitators = recordArr[index]["Carers.Care_Facilitier"];
        if (care_facilitators !="")
        {
          care_facilitators = recordArr[index]["Carers.Care_Facilitier"].trim();
        }
        var shiftcount = recordArr[index].Numberofshift || 0;
        var schstartdt= recordArr[index].Scheduled_Start_Date;
        var schenddt= recordArr[index].Scheduled_End_Date;
        var Shiftcancad =recordArr[index].Concat_Shift_Info;
        var shift_temp= recordArr[index].Shift;
        var shiftid=recordArr[index]["Shift.ID"];
        var shiftName=shift_temp.display_value;
        var clientData = recordArr[index].Clients.display_value.trim();
        var client_id = recordArr[index].Clients.ID.trim();
        var shfit_start_time = recordArr[index].Scheduled_Start_Time;
        var shift_end_time = recordArr[index].Scheduled_End_Time;
        var shift_type = recordArr[index]["Shift.Shift_Type"];
        var shift_end_day = recordArr[index]["Shift.End_Day"];
        var Card_Color = recordArr[index]["Shift.Card_Color"] || "#06518b";
        shiftDataArr.push(
          {
            "EmpName":carer,
            "start_date":start_date,
            "shift":shiftName,
            "client":clientData,
            "rec_id":rec_id,
            "care_facilitators":care_facilitators,
            "shiftid":shiftid,
            "schstartdt":moment(schstartdt).format('DD-MMM-YYYY'),
            "schenddt": moment(schenddt).format('DD-MMM-YYYY'),
            "shiftstarttime":shfit_start_time,
              "shiftendtime":shift_end_time,
            "shifttype":shift_type,
            "endday": shift_end_day,
            "carer_id": carer_id,
            "client_id":client_id,
            "concat_shift_name":Shiftcancad,
            "Card_Color":Card_Color
          }
        );
      }
    } catch (error){
      console.log("error:", error);
      return false;
    }
  }
  // Your code here
  return emplist;
}

//  function to fetch the shift details
async function GetShiftDetails_Func(clientCheckID){
  var resultData=[];
  try{
    for (let j = 1; j <3; j++)
    {
      const Shift_response = await ZOHO.CREATOR.API.getAllRecords({
        reportName: "Shift_Report1",
        criteria: '(Clients == ' + clientCheckID + ' && Shift_Status == "Open")',
        page: j,
        pageSize:200
      });
      const recordArr = await Shift_response.data;
      for (var index_shift in recordArr)
      {
        resultData.push({
          "shiftName":recordArr[index_shift].Shift_Name,
          "shiftID":recordArr[index_shift].ID
        });
      }
    }
  }catch (error){
    console.log("error",error);
  }
  return resultData;
}
