$(document).ready(function() {
    var cur_year = new Date().getFullYear();
    let currentYear = new Date().getFullYear(); // Get current year
    const numberOfMonthsInYear = 12; // Total number of months in a year

    let currentMonth = new Date(currentYear, 0, 1); // Start with January of the current year

    displayYearInHeader(currentYear);
    displayCurrentYear(currentYear);
    setDefaultMonth(); // Set default value for monthInput

    $('#monthInput').on('input', function() {
        const selectedDate = new Date($(this).val() + '-01'); // Get selected date (e.g., "YYYY-MM")
        currentYear = selectedDate.getFullYear();
        displayYearInHeader(currentYear); // Display months starting from January of the selected year
        displayCurrentYear(currentYear);
        if (currentYear != cur_year) {
            $("#week_details").css("width", "94%");
            $("#previous_btns_details").css("width", "2%");
            $("#current_btns_details").css("width", "2%");
            $("#left_btns_details").css("width", "2%");
            $("#current_btns_details").css("display", "block");
        }
    });

    $(document).on('click', '#next', function() {
        currentYear++; // Move to the next year
        displayYearInHeader(currentYear); // Display months starting from January of the next year
        displayCurrentYear(currentYear);
        $("#week_details").css("width", "94%");
        $("#previous_btns_details").css("width", "2%");
        $("#current_btns_details").css("width", "2%");
        $("#left_btns_details").css("width", "2%");
        $("#current_btns_details").css("display", "block");
    });

    $(document).on('click', '#previous', function() {
        currentYear--; // Move to the previous year
        displayYearInHeader(currentYear); // Display months starting from January of the previous year
        displayCurrentYear(currentYear);
        $("#week_details").css("width", "94%");
        $("#previous_btns_details").css("width", "2%");
        $("#current_btns_details").css("width", "2%");
        $("#left_btns_details").css("width", "2%");
        $("#current_btns_details").css("display", "block");
    });

    $(document).on('click', '#current', function() {
        currentYear = new Date().getFullYear(); // Reset to the current year
        displayYearInHeader(currentYear); // Display months starting from January of the current year
        displayCurrentYear(currentYear);
        updateMonthInput(); // Update the month input field
        $("#current_btns_details").css("display", "none");
        $("#week_details").css("width", "96%");
        $("#previous_btns_details").css("width", "2%");
        $("#left_btns_details").css("width", "2%");
    });

    function displayYearInHeader(year) {
        $('#datesBody').empty();
        const datesRow = $('#datesRow');
        datesRow.empty(); // Clear existing content

        // Add carer column
        datesRow.append('<td style="width:250px; font-weight:bold;">Client</td>');

        // Add month columns dynamically for the entire year
        const today = new Date();
        for (let i = 0; i < numberOfMonthsInYear; i++) {
            const month = new Date(year, i, 1);
            const formattedMonth = moment(month).format('MMM YYYY');
            const isCurrentMonth = (month.getFullYear() === today.getFullYear() && month.getMonth() === today.getMonth());
            datesRow.append(`<th class="${isCurrentMonth ? 'current-month' : ''}" currentdate="${formattedMonth}">${formattedMonth}</th>`);
        }

        // Now you can proceed with populating shift data accordingly
        // Example: populateShiftData(startMonth, count);
        if (clientArr.length == 0 && marsDataArr.length == 0) {
            ZOHO.CREATOR.init().then(function(data) {
                console.log("Zoho Page loaded");
                DisplayFilterData_Func().then(ReturnVal => {
                    console.log("ReturnVal:", ReturnVal);
                    console.log("marsDataArr:", marsDataArr);
                    DisplayShiftDetails_Func()
                });
            });
        } else {
            DisplayShiftDetails_Func()
        }
    }

    function displayCurrentYear(year) {
        $('#currentYearDisplay').text(year); // Display current year in the button tag
    }

    function updateMonthInput() {
        const currentDate_month = moment();
        const currentMonthAbbreviation = currentDate_month.format("MM");
        const monthInput = document.getElementById('monthInput');
        const defaultValue = `${currentYear}-${currentMonthAbbreviation}`; // Format: "YYYY-MM"
        monthInput.value = defaultValue;
    }

    function setDefaultMonth() {
        const monthInput = document.getElementById('monthInput');
        const currentDate = new Date();
        const year = currentDate.getFullYear();
        const month = ('0' + (currentDate.getMonth() + 1)).slice(-2); // Current month as MM (01-12)
        const defaultValue = `${year}-${month}`; // Format: "YYYY-MM"
        monthInput.value = defaultValue;
    }

    function populateShiftData(startMonth, count) {
        const tbody = $('#yearlyCalendar tbody');
        tbody.empty(); // Clear existing rows

        // Example: Loop through months and populate shift data rows
        for (let i = 0; i < count; i++) {
            const month = new Date(startMonth.getFullYear(), startMonth.getMonth() + i, 1);
            const formattedMonth = moment(month).format('MMM YYYY');

            // Example: Append shift data rows for each month
            tbody.append(`<tr><td>${formattedMonth} Shift Data</td></tr>`);
        }
  }
  
});
function DisplayShiftDetails_Func() {
  $('#datesBody').empty();
  var ClientOptions = $(".clientdataDD").select2('data');
  var clientnameValues = ClientOptions.map(function (option) {
    return { clientname: option.element.getAttribute('client_name') };
  });
  var CareFaciOptions = $(".carefacidataDD").select2('data');
  var carefaciValues = CareFaciOptions.map(function (option) {
    return { carefaciname: option.element.getAttribute('care_facilitier_name') };
  });
  PostShift_TO_Table_Func(clientnameValues, carefaciValues);
}
  
var changeEventTriggered = false;
$(document).delegate('.carerdataDD, .clientdataDD, .carefacidataDD', 'change', function(){
  $('#datesBody').empty();
  var ClientOptions = $(".clientdataDD").select2('data');
  var clientnameValues = ClientOptions.map(function (option) {
    return { clientname: option.element.getAttribute('client_name') };
  });
  var CareFaciOptions = $(".carefacidataDD").select2('data');
  var carefaciValues = CareFaciOptions.map(function (option) {
    return { carefaciname: option.element.getAttribute('care_facilitier_name') };
  });
  PostShift_TO_Table_Func(clientnameValues, carefaciValues);
});
// Filter Reset button script
$(document).delegate(".resetfilter", 'click', function(){
  // console.log("resetfilter button clicked");

  $(".clientdataDD, .carefacidataDD").val([]).trigger("change");

  $('#datesBody').empty();
    for (const Empelement of clientArr) {
      const clientname = Empelement.clientName;
      const clientID = Empelement.clientID;
      var bodyhtml = '<td class="emp_td" clientID="' + clientID + '"><span>' + clientname + '</span></td>';
      

      $('#datesRow th').each(function () {
        var DateCurrent = $(this).attr("currentdate");
        var splitData = DateCurrent.split(" ");
        var monthdata = splitData[0];
        var yearData = splitData[1];
        // console.log("monthdata", monthdata);
        // console.log("yearData", yearData);
        console.log("-------------");
        const searchResult = searchRecord(marsDataArr, monthdata, yearData, clientID);
        // console.log("searchResult:", searchResult);
        if (searchResult.length > 0) {
          console.log("searchResult:", searchResult);
          var divcontent = "";
          for (let mw = 0; mw < searchResult.length; mw++) {
            var receReceived_Date = searchResult[mw].rec_date;
            var status = searchResult[mw].Status;
            console.log("receReceived_Date", receReceived_Date);
            actionColorMap.hasOwnProperty(status);
            var color = actionColorMap[status];
              var newdatepresent = new Date();
            if (status == "Received" || status == "Audit/Scanned")
            {
                divcontent += "<div class='empdiv' style='border-top: 2px solid " + color + "; border-bottom: 2px solid " + color + "; border-left: 15px solid " + color + "; border-right: 2px solid " + color + ";border-radius:5px;' client_id='" + searchResult[mw].client_id + "' rec_id='" + searchResult[mw].rec_id + "' client_name='"+searchResult[mw].client+"' presentmonth='"+monthdata+"' presentyear='"+yearData+"' status='"+status+"' care_factiliter='"+searchResult[mw].care_factiliter+"' received_by='"+searchResult[mw].Received_By+"' checked_by='"+searchResult[mw].Checked_By+"' Notes='"+searchResult[mw].Notes+"' received_date='"+receReceived_Date+"' sent_date='"+searchResult[mw].Sent_for_Date+"' request_date='"+searchResult[mw].Requested_Date+"' audit_date='"+searchResult[mw].Audit_Scanned_Date+"'>" +searchResult[mw].rec_date+ "</div>";
            }
            else
            {
                  divcontent += "<div class='empdiv' style='border-top: 2px solid " + color + "; border-bottom: 2px solid " + color + "; border-left: 15px solid " + color + "; border-right: 2px solid " + color + ";border-radius:5px;color:transparent;user-select: none;'  client_id='" + searchResult[mw].client_id + "' rec_id='" + searchResult[mw].rec_id + "' client_name='"+searchResult[mw].client+"' presentmonth='"+monthdata+"' presentyear='"+yearData+"' status='"+status+"' care_factiliter='"+searchResult[mw].care_factiliter+"' received_by='"+searchResult[mw].Received_By+"' checked_by='"+searchResult[mw].Checked_By+"' Notes='"+searchResult[mw].Notes+"' received_date='"+receReceived_Date+"' sent_date='"+searchResult[mw].Sent_for_Date+"' request_date='"+searchResult[mw].Requested_Date+"' audit_date='"+searchResult[mw].Audit_Scanned_Date+"'>"+moment(newdatepresent).format("DD-MMM-YYYY")+"</div>";
            }
          }
          bodyhtml += "<td>" + divcontent + "</td>";
        }
        else {
            var status_plus ="Sent for"
          bodyhtml += "<td class='empbtn' currentdate='" + DateCurrent + "' client_id='" + clientID + "'  client_name='"+clientname+"' presentmonth='"+monthdata+"' presentyear='"+yearData+"' status='"+status_plus+"' received_by='' checked_by='' Notes='' received_date='' sent_date='' request_date='' audit_date=''><i style='font-size:15px' class='far fa-edit'></i></td>";
        }
      });
   
      $('#datesBody').append("<tr>" + bodyhtml + "</tr>");
    }
});

async function PostShift_TO_Table_Func(clientnameValues, carefaciValues) {
  // $('#datesBody').empty();
    var resultData = generateCombinations(clientnameValues, carefaciValues);
  resultData = resultData.filter(function(item) {
    return item.trim() !== '{}';
  });
  // console.log("marsData:", marsDataArr);
  console.log("resultData:", resultData);
  if (resultData.length > 0) {
    $(".resetfilter").attr("disabled", false);
    var CarerClientDataArr = [];
    resultData.forEach(element => {
      var jsonObject = JSON.parse(element);
      console.log("jsonObject:", jsonObject);
      const keysToCheck = ['clientname', 'carefaciname'];
      const allKeysExist = keysToCheck.every(key => jsonObject.hasOwnProperty(key));
    if (allKeysExist) // client and careFaci function
      {
        var clientName = jsonObject.clientname;
        var carefaciName = jsonObject.carefaciname;
        var CarerClientUnique = removeDuplicates(wholeCareClient, ['clientName', 'careFaciName']);
        const CarerClientuniqueData = CarerClientUnique.filter(item => item.clientName === clientName && item.careFaciName === carefaciName);
        if (CarerClientuniqueData.length > 0) {
          CarerClientuniqueData.forEach(element => {
            element["filterType"] = "clientcarefaci";
            CarerClientDataArr.push(element);
          });
        }
      }
      else if (jsonObject.hasOwnProperty('clientname')) // Client name filter
      {
        var clientName = jsonObject.clientname;
        var CarerClientUnique = removeDuplicates(wholeCareClient, ['clientName']);
        const CarerClientuniqueData = CarerClientUnique.filter(item => item.clientName == clientName);
        if (CarerClientuniqueData.length > 0) {
          CarerClientuniqueData.forEach(element => {
            element["filterType"] = "client";
            CarerClientDataArr.push(element);
          });
        }
      }
      else if (jsonObject.hasOwnProperty('carefaciname')) // Care Faci Name filter
      {
        var carefaciName = jsonObject.carefaciname;
        var uniqueDataTemp = removeDuplicates(wholeCareClient, ['carerName', 'clientName', 'careFaciName']);
        const uniqueCareFaciData = uniqueDataTemp.filter(item => item.careFaciName === carefaciName);
        if (uniqueCareFaciData.length > 0) {
          uniqueCareFaciData.forEach(element => {
            element["filterType"] = "careFaci";
            CarerClientDataArr.push(element);
          });
        }
      }
    });
    console.log("CarerClientDataArr:", CarerClientDataArr);
    if (CarerClientDataArr.length > 0) {
      // FindandAppend_Filtered_ShiftDetailstest (CarerClientDataArr);
      FindandAppend_Filtered_ShiftDetails(CarerClientDataArr);
    }
    else {
      var bodyhtml = "<td colspan='12'>No mapping records were found for this search data</td>";
      $('#datesBody').append("<tr>" + bodyhtml + "</tr>");
    }
  }
  else {
    for (const Empelement of clientArr) {
      const clientname = Empelement.clientName;
      const clientID = Empelement.clientID;
      var bodyhtml = '<td class="emp_td" clientID="' + clientID + '"><span>' + clientname + '</span></td>';
      

      $('#datesRow th').each(function () {
        var DateCurrent = $(this).attr("currentdate");
        var splitData = DateCurrent.split(" ");
        var monthdata = splitData[0];
        var yearData = splitData[1];
        // console.log("monthdata", monthdata);
        // console.log("yearData", yearData);
        console.log("-------------");
        const searchResult = searchRecord(marsDataArr, monthdata, yearData, clientID);
        // console.log("searchResult:", searchResult);
        if (searchResult.length > 0) {
          console.log("searchResult:", searchResult);
          var divcontent = "";
          for (let mw = 0; mw < searchResult.length; mw++) {
            var receReceived_Date = searchResult[mw].rec_date;
            var status = searchResult[mw].Status;
            actionColorMap.hasOwnProperty(status);
            var color = actionColorMap[status];
              var newdatepresent = new Date();
            if (status == "Received" || status == "Audit/Scanned")
            {
                divcontent += "<div class='empdiv' style='border-top: 2px solid " + color + "; border-bottom: 2px solid " + color + "; border-left: 15px solid " + color + "; border-right: 2px solid " + color + ";border-radius:5px;' client_id='" + searchResult[mw].client_id + "' rec_id='" + searchResult[mw].rec_id + "' client_name='"+searchResult[mw].client+"' presentmonth='"+monthdata+"' presentyear='"+yearData+"' status='"+status+"' care_factiliter='"+searchResult[mw].care_factiliter+"' received_by='"+searchResult[mw].Received_By+"' checked_by='"+searchResult[mw].Checked_By+"' Notes='"+searchResult[mw].Notes+"' received_date='"+receReceived_Date+"' sent_date='"+searchResult[mw].Sent_for_Date+"' request_date='"+searchResult[mw].Requested_Date+"' audit_date='"+searchResult[mw].Audit_Scanned_Date+"'>" +searchResult[mw].rec_date+ "</div>";
            }
            else
            {
                  divcontent += "<div class='empdiv' style='border-top: 2px solid " + color + "; border-bottom: 2px solid " + color + "; border-left: 15px solid " + color + "; border-right: 2px solid " + color + ";border-radius:5px;color:transparent;user-select: none;'  client_id='" + searchResult[mw].client_id + "' rec_id='" + searchResult[mw].rec_id + "' client_name='"+searchResult[mw].client+"' presentmonth='"+monthdata+"' presentyear='"+yearData+"' status='"+status+"' care_factiliter='"+searchResult[mw].care_factiliter+"' received_by='"+searchResult[mw].Received_By+"' checked_by='"+searchResult[mw].Checked_By+"' Notes='"+searchResult[mw].Notes+"' received_date='"+receReceived_Date+"' sent_date='"+searchResult[mw].Sent_for_Date+"' request_date='"+searchResult[mw].Requested_Date+"' audit_date='"+searchResult[mw].Audit_Scanned_Date+"'>"+moment(newdatepresent).format("DD-MMM-YYYY")+"</div>";
            }
          }
          bodyhtml += "<td>" + divcontent + "</td>";
        }
        else {
          var status_plus ="Sent for"
          bodyhtml += "<td class='empbtn' currentdate='" + DateCurrent + "' client_id='" + clientID + "'  client_name='"+clientname+"' presentmonth='"+monthdata+"' presentyear='"+yearData+"' status='"+status_plus+"' received_by='' checked_by='' Notes='' received_date='' sent_date='' request_date='' audit_date=''><i style='font-size:15px' class='far fa-edit'></i></td>";
        }
      });
   
      $('#datesBody').append("<tr>" + bodyhtml + "</tr>");
    }
  }
}
function FindandAppend_Filtered_ShiftDetails(CarerClientDataArr) {
  $("#datesBody").empty();
  console.log("CarerClientDataArr:", CarerClientDataArr);
  var result = groupByCarerName(CarerClientDataArr);
  console.log("result",result);
  Object.keys(result).forEach(key => {
    const carername = key; // Extract the name from the key
    const findCarerInfoByName = (wholeCareClient, carerName) => {
      const carer = wholeCareClient.find(item => item.clientName === carerName);
      if (carer) {
        return { carerID: carer.clientID };
      } else {
        return { carerID: null };
      }
    };
    const carerInfo = findCarerInfoByName(wholeCareClient, carername);
    const carerID = carerInfo.carerID;
    console.log("carerInfo", carerInfo);
    var bodyhtml = '<td class="emp_td" clientID="' + carerID + '"><span>' + carername + '</span></td>';
    $('#datesRow th').each(function () {
      var DateCurrent = $(this).attr("currentdate");
      var splitData = DateCurrent.split(" ");
      var monthdata = splitData[0];
      var yearData = splitData[1];
      var divcontent="";
      var outsideResult = 0;
      result[carername].forEach(function (itemData) {
        var clientName = itemData.clientID;
        var carefaciName = itemData.careFaciName;
        var FilterType = itemData.filterType;
        if (FilterType == "clientcarefaci") {
          const searchResult = searchRecord_With_Filter(marsDataArr, clientName, carefaciName, monthdata, yearData,0);
          console.log("searchResult:", searchResult.length);
          if (searchResult.length>0)
          {
            outsideResult=1;
            for (let mw = 0; mw < searchResult.length; mw++) {
              var receReceived_Date = searchResult[mw].rec_date;
              console.log("receReceived_Date", receReceived_Date);
              var status = searchResult[mw].Status;
            actionColorMap.hasOwnProperty(status);
              var color = actionColorMap[status];
              var newdatepresent = new Date();
            if (status == "Received" || status == "Audit/Scanned")
            {
                divcontent += "<div class='empdiv' style='border-top: 2px solid " + color + "; border-bottom: 2px solid " + color + "; border-left: 15px solid " + color + "; border-right: 2px solid " + color + ";border-radius:5px;' client_id='" + searchResult[mw].client_id + "' rec_id='" + searchResult[mw].rec_id + "' client_name='"+searchResult[mw].client+"' presentmonth='"+monthdata+"' presentyear='"+yearData+"' status='"+status+"' care_factiliter='"+searchResult[mw].care_factiliter+"' received_by='"+searchResult[mw].Received_By+"' checked_by='"+searchResult[mw].Checked_By+"' Notes='"+searchResult[mw].Notes+"' received_date='"+receReceived_Date+"' sent_date='"+searchResult[mw].Sent_for_Date+"' request_date='"+searchResult[mw].Requested_Date+"' audit_date='"+searchResult[mw].Audit_Scanned_Date+"'>" +searchResult[mw].rec_date+ "</div>";
            }
            else
            {
                  divcontent += "<div class='empdiv' style='border-top: 2px solid " + color + "; border-bottom: 2px solid " + color + "; border-left: 15px solid " + color + "; border-right: 2px solid " + color + ";border-radius:5px;color:transparent;user-select: none;'  client_id='" + searchResult[mw].client_id + "' rec_id='" + searchResult[mw].rec_id + "' client_name='"+searchResult[mw].client+"' presentmonth='"+monthdata+"' presentyear='"+yearData+"' status='"+status+"' care_factiliter='"+searchResult[mw].care_factiliter+"' received_by='"+searchResult[mw].Received_By+"' checked_by='"+searchResult[mw].Checked_By+"' Notes='"+searchResult[mw].Notes+"' received_date='"+receReceived_Date+"' sent_date='"+searchResult[mw].Sent_for_Date+"' request_date='"+searchResult[mw].Requested_Date+"' audit_date='"+searchResult[mw].Audit_Scanned_Date+"'>"+moment(newdatepresent).format("DD-MMM-YYYY")+"</div>";
            }
            }
          }
        }
        else if (FilterType=="client")
        {
          const searchResult = searchRecord_With_Filter(marsDataArr, clientName, 0, monthdata, yearData,0);
          console.log("searchResult:", searchResult.length);
          if (searchResult.length>0)
          {
            outsideResult=1;
            for (let mw = 0; mw < searchResult.length; mw++) {
              var receReceived_Date = searchResult[mw].rec_date;
              console.log("receReceived_Date", receReceived_Date);
                          var status = searchResult[mw].Status;
            actionColorMap.hasOwnProperty(status);
              var color = actionColorMap[status];
              var newdatepresent = new Date();
            if (status == "Received" || status == "Audit/Scanned")
            {
                divcontent += "<div class='empdiv' style='border-top: 2px solid " + color + "; border-bottom: 2px solid " + color + "; border-left: 15px solid " + color + "; border-right: 2px solid " + color + ";border-radius:5px;' client_id='" + searchResult[mw].client_id + "' rec_id='" + searchResult[mw].rec_id + "' client_name='"+searchResult[mw].client+"' presentmonth='"+monthdata+"' presentyear='"+yearData+"' status='"+status+"' care_factiliter='"+searchResult[mw].care_factiliter+"' received_by='"+searchResult[mw].Received_By+"' checked_by='"+searchResult[mw].Checked_By+"' Notes='"+searchResult[mw].Notes+"' received_date='"+receReceived_Date+"' sent_date='"+searchResult[mw].Sent_for_Date+"' request_date='"+searchResult[mw].Requested_Date+"' audit_date='"+searchResult[mw].Audit_Scanned_Date+"'>" +searchResult[mw].rec_date+ "</div>";
            }
            else
            {
                  divcontent += "<div class='empdiv' style='border-top: 2px solid " + color + "; border-bottom: 2px solid " + color + "; border-left: 15px solid " + color + "; border-right: 2px solid " + color + ";border-radius:5px;color:transparent;user-select: none;'  client_id='" + searchResult[mw].client_id + "' rec_id='" + searchResult[mw].rec_id + "' client_name='"+searchResult[mw].client+"' presentmonth='"+monthdata+"' presentyear='"+yearData+"' status='"+status+"' care_factiliter='"+searchResult[mw].care_factiliter+"' received_by='"+searchResult[mw].Received_By+"' checked_by='"+searchResult[mw].Checked_By+"' Notes='"+searchResult[mw].Notes+"' received_date='"+receReceived_Date+"' sent_date='"+searchResult[mw].Sent_for_Date+"' request_date='"+searchResult[mw].Requested_Date+"' audit_date='"+searchResult[mw].Audit_Scanned_Date+"'>"+moment(newdatepresent).format("DD-MMM-YYYY")+"</div>";
            }
            }
          }
        }
        else if (FilterType == "careFaci")
        {
          const searchResult = searchRecord_With_Filter(marsDataArr, clientName, carefaciName, monthdata, yearData,1);
          console.log("searchResult:", searchResult.length);
          if (searchResult.length>0)
          {
            outsideResult=1;
            for (let mw = 0; mw < searchResult.length; mw++) {
              var receReceived_Date = searchResult[mw].rec_date;
              console.log("receReceived_Date", receReceived_Date);
                          var status = searchResult[mw].Status;
            actionColorMap.hasOwnProperty(status);
              var color = actionColorMap[status];
              var newdatepresent = new Date();
            if (status == "Received" || status == "Audit/Scanned")
            {
                divcontent += "<div class='empdiv' style='border-top: 2px solid " + color + "; border-bottom: 2px solid " + color + "; border-left: 15px solid " + color + "; border-right: 2px solid " + color + ";border-radius:5px;' client_id='" + searchResult[mw].client_id + "' rec_id='" + searchResult[mw].rec_id + "' client_name='"+searchResult[mw].client+"' presentmonth='"+monthdata+"' presentyear='"+yearData+"' status='"+status+"' care_factiliter='"+searchResult[mw].care_factiliter+"' received_by='"+searchResult[mw].Received_By+"' checked_by='"+searchResult[mw].Checked_By+"' Notes='"+searchResult[mw].Notes+"' received_date='"+receReceived_Date+"' sent_date='"+searchResult[mw].Sent_for_Date+"' request_date='"+searchResult[mw].Requested_Date+"' audit_date='"+searchResult[mw].Audit_Scanned_Date+"'>" +searchResult[mw].rec_date+ "</div>";
            }
            else
            {
                  divcontent += "<div class='empdiv' style='border-top: 2px solid " + color + "; border-bottom: 2px solid " + color + "; border-left: 15px solid " + color + "; border-right: 2px solid " + color + ";border-radius:5px;color:transparent;user-select: none;'  client_id='" + searchResult[mw].client_id + "' rec_id='" + searchResult[mw].rec_id + "' client_name='"+searchResult[mw].client+"' presentmonth='"+monthdata+"' presentyear='"+yearData+"' status='"+status+"' care_factiliter='"+searchResult[mw].care_factiliter+"' received_by='"+searchResult[mw].Received_By+"' checked_by='"+searchResult[mw].Checked_By+"' Notes='"+searchResult[mw].Notes+"' received_date='"+receReceived_Date+"' sent_date='"+searchResult[mw].Sent_for_Date+"' request_date='"+searchResult[mw].Requested_Date+"' audit_date='"+searchResult[mw].Audit_Scanned_Date+"'>"+moment(newdatepresent).format("DD-MMM-YYYY")+"</div>";
            }
            }
          }
        }
      });
      console.log("divcontent:", divcontent);
      if (outsideResult==0)
      {
        
        var status_plus ="Sent for"
          bodyhtml += "<td class='empbtn' currentdate='" + DateCurrent + "' client_id='" + carerID + "'  client_name='"+carername+"' presentmonth='"+monthdata+"' presentyear='"+yearData+"' status='"+status_plus+"' received_by='' checked_by='' Notes='' received_date='' sent_date='' request_date='' audit_date=''><i style='font-size:15px' class='far fa-edit'></i></td>";
      }
      else
      {
        bodyhtml+="<td>"+divcontent+"</td>";
      }
    });
    $('#datesBody').append("<tr>"+bodyhtml+"</tr>");
    });
}
