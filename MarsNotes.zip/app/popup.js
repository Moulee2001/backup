
$(document).delegate('.empdiv', 'click', function () {
      $(".btn-sve span").text("Update");
  $(".del_btn").attr("disabled",false);
    var Emp_Recid = this.getAttribute("rec_id");
    var status = this.getAttribute("status");
    $('#recid').val(Emp_Recid);
    // var rowData = $(this).closest("tr");
    var client_id = this.getAttribute("client_id");
    var client_name = this.getAttribute("client_name");
    $('#dropdownname_cl_popup').attr('clientid',client_id);
    $('#dropdownname_cl_popup').val(client_name);
    var month = this.getAttribute("presentmonth");
    var year = this.getAttribute("presentyear");
    $('#dropdownname_cl_popup').attr('month', month);
    $('#dropdownname_cl_popup').attr('year', year);
    var Notes = this.getAttribute("notes");
    var Checked_By = this.getAttribute("checked_by");
    var Received_By = this.getAttribute("received_by");
    var rec_formatted = this.getAttribute("received_date");
    var Received_Date = moment(rec_formatted).format("YYYY-MM-DD");
    var test = "";
    var checked = "";
    var received = "";
    var rec_date = "";
    var sentdate_formatted = this.getAttribute("sent_date");
    var sent_date = moment(sentdate_formatted).format("YYYY-MM-DD");
    var req_formatted = this.getAttribute("request_date");
    var requested_date = moment(req_formatted).format("YYYY-MM-DD");
    var audit_formatted = this.getAttribute("audit_date");
    var audit_date =  moment(audit_formatted).format("YYYY-MM-DD");
    var current_date = $("#current_date").val();
    $('#status').val(status);
    console.log("testing",requested_date)
    if (status == "Received")
    {
        $("#hidden").show();
        $("#hidden1").show();
        $("#hidden2").show();
        $("#hidden3").show();
        $("#hidden4").hide();
       $("#hidden5").hide();
       $("#hidden6").hide();
        // var Notes = this.getAttribute("notes");
        if (Notes === "")
        {
            $('#Notes').val(test);
        }
        else
        {
            $('#Notes').val(Notes);
        }
        // var Checked_By = this.getAttribute("checked_by");
        if (Checked_By === "")
        {
            $("#Checked_By_drp").val(loginusername);
        }
        else
        {
            $("#Checked_By_drp").val(Checked_By);
        }
        
        // var Received_By = this.getAttribute("received_by");
        if (Received_By === "")
        {
            $("#Received_By_drp").val(loginusername);
        }
        else
        {
            $("#Received_By_drp").val(Received_By);
        }
        if (sentdate_formatted === "")
        {
            $('#Sent_Date').val("");
        }
        else
        {
            $('#Sent_Date').val(sent_date);
        }
        if (rec_formatted === "")
        {
            $("#Received_Date").val(current_date);
        }
        else
        {
            $("#Received_Date").val(Received_Date);
        }
        if (req_formatted === "")
        {

            $('#Requested_Date').val("");
        }
        else
        {
            $('#Requested_Date').val(requested_date);
        }
        if (audit_formatted === "")
        {
            $('#Audit_Date').val("");
        }
        else
        {
            $('#Audit_Date').val(audit_date);
        }
        
    }
    else if (status == "Audit/Scanned")
    {
        $("#hidden").hide();
        $("#hidden1").hide();
        $("#hidden2").hide();
        $("#hidden3").show();
               $("#hidden4").hide();
       $("#hidden5").hide();
       $("#hidden6").show();
        // var Notes = this.getAttribute("notes");
        if (Notes === "")
        {
            $('#Notes').val(test);
        }
        else
        {
            $('#Notes').val(Notes);
        }
        // var Checked_By = this.getAttribute("checked_by");
        if (Checked_By === "")
        {
            $("#Checked_By_drp").val("");
        }
        else
        {
            $("#Checked_By_drp").val(Checked_By);
        }
        
        // var Received_By = this.getAttribute("received_by");
        if (Received_By === "")
        {
            $("#Received_By_drp").val("");
        }
        else
        {
            $("#Received_By_drp").val(Received_By);
        }
        if (sentdate_formatted === "")
        {
            $('#Sent_Date').val("");
        }
        else
        {
            $('#Sent_Date').val(sent_date);
        }
        if (rec_formatted === "")
        {
            $("#Received_Date").val("");
        }
        else
        {
            $("#Received_Date").val(Received_Date);
        }
        if (req_formatted === "")
        {

            $('#Requested_Date').val("");
        }
        else
        {
            $('#Requested_Date').val(requested_date);
        }
        if (audit_formatted === "")
        {
            $('#Audit_Date').val(current_date);
        }
        else
        {
            $('#Audit_Date').val(audit_date);
        }
     
    }
    else if(status == "Requested")
    {
        $("#hidden").hide();
        $("#hidden1").hide();
        $("#hidden2").hide();
        $("#hidden3").hide();
        $("#hidden4").hide();
       $("#hidden5").show();
       $("#hidden6").hide();
        if (Notes === "")
        {
            $('#Notes').val("");
        }
        else
        {
            $('#Notes').val(Notes);
        }
        // var Checked_By = this.getAttribute("checked_by");
        if (Checked_By === "")
        {
            $("#Checked_By_drp").val("");
        }
        else
        {
            $("#Checked_By_drp").val(Checked_By);
        }
        
        // var Received_By = this.getAttribute("received_by");
        if (Received_By === "")
        {
            $("#Received_By_drp").val("");
        }
        else
        {
            $("#Received_By_drp").val(Received_By);
        }
        if (sentdate_formatted === "")
        {
            $('#Sent_Date').val("");
        }
        else
        {
            $('#Sent_Date').val(sent_date);
        }
        if (rec_formatted === "")
        {
            $("#Received_Date").val("");
        }
        else
        {
            $("#Received_Date").val(Received_Date);
        }
        if (req_formatted === "")
        {

            $('#Requested_Date').val(current_date);
        }
        else
        {
            $('#Requested_Date').val(requested_date);
        }
        if (audit_formatted === "")
        {
            $('#Audit_Date').val("");
        }
        else
        {
            $('#Audit_Date').val(audit_date);
        }
    }
    else if (status == "Sent for")
    {
        $("#hidden").hide();
        $("#hidden1").hide();
        $("#hidden2").hide();
        $("#hidden3").hide();
               $("#hidden4").show();
       $("#hidden5").hide();
       $("#hidden6").hide();
        if (Notes === "")
        {
            $('#Notes').val("");
        }
        else
        {
            $('#Notes').val(Notes);
        }
        // var Checked_By = this.getAttribute("checked_by");
        if (Checked_By === "")
        {
            $("#Checked_By_drp").val("");
        }
        else
        {
            $("#Checked_By_drp").val(Checked_By);
        }
        
        // var Received_By = this.getAttribute("received_by");
        if (Received_By === "")
        {
            $("#Received_By_drp").val("");
        }
        else
        {
            $("#Received_By_drp").val(Received_By);
        }
        if (sentdate_formatted === "")
        {
            $('#Sent_Date').val(current_date);
        }
        else
        {
            $('#Sent_Date').val(sent_date);
        }
        if (rec_formatted === "")
        {
            $("#Received_Date").val("");
        }
        else
        {
            $("#Received_Date").val(Received_Date);
        }
        if (req_formatted === "")
        {

            $('#Requested_Date').val("");
        }
        else
        {
            $('#Requested_Date').val(requested_date);
        }
        if (audit_formatted === "")
        {
            $('#Audit_Date').val("");
        }
        else
        {
            $('#Audit_Date').val(audit_date);
        }
    }
    $(document).on("change", "#status", function () {
        var status_val = $('#status').val();
        console.log("status_val", status_val);
        if (status_val == "Received")
        {
            $("#hidden").show();
            $("#hidden1").show();
            $("#hidden2").show();
            $("#hidden3").show();
        // var Notes = this.getAttribute("notes");
        if (Notes === "")
        {
            $('#Notes').val(test);
        }
        else
        {
            $('#Notes').val(Notes);
        }
        // var Checked_By = this.getAttribute("checked_by");
        if (Checked_By === "")
        {
            $("#Checked_By_drp").val(loginusername);
        }
        else
        {
            $("#Checked_By_drp").val(Checked_By);
        }
        
        // var Received_By = this.getAttribute("received_by");
        if (Received_By === "")
        {
            $("#Received_By_drp").val(loginusername);
        }
        else
        {
            $("#Received_By_drp").val(Received_By);
        }
        if (sentdate_formatted === "")
        {
            $('#Sent_Date').val("");
        }
        else
        {
            $('#Sent_Date').val(sent_date);
        }
        if (rec_formatted === "")
        {
            $("#Received_Date").val(current_date);
        }
        else
        {
            $("#Received_Date").val(Received_Date);
        }
                if (req_formatted === "")
        {

            $('#Requested_Date').val("");
        }
        else
        {
            $('#Requested_Date').val(requested_date);
        }
        if (audit_formatted === "")
        {
            $('#Audit_Date').val("");
        }
        else
        {
            $('#Audit_Date').val(audit_date);
        }
        }
        else if (status_val == "Audit/Scanned")
        {
            $("#hidden").hide();
            $("#hidden1").hide();
            $("#hidden2").hide();
            $("#hidden3").show();
           
        if (Notes === "")
        {
           
            $('#Notes').val(test);
        }
        else
        {
            $('#Notes').val(Notes);
            }
        // var Checked_By = this.getAttribute("checked_by");
        if (Checked_By === "")
        {
            $("#Checked_By_drp").val("");
        }
        else
        {
            $("#Checked_By_drp").val(Checked_By);
        }
        
        // var Received_By = this.getAttribute("received_by");
        if (Received_By === "")
        {
            $("#Received_By_drp").val("");
        }
        else
        {
            $("#Received_By_drp").val(Received_By);
        }
        if (sentdate_formatted === "")
        {
            $('#Sent_Date').val("");
        }
        else
        {
            $('#Sent_Date').val(sent_date);
        }
        if (rec_formatted === "")
        {
            $("#Received_Date").val("");
        }
        else
        {
            $("#Received_Date").val(Received_Date);
        }
        if (req_formatted === "")
        {

            $('#Requested_Date').val("");
        }
        else
        {
            $('#Requested_Date').val(requested_date);
        }
        if (audit_formatted === "")
        {
            $('#Audit_Date').val(current_date);
        }
        else
        {
            $('#Audit_Date').val(audit_date);
        }
        }
    else if(status_val == "Requested")
    {
        $("#hidden").hide();
        $("#hidden1").hide();
        $("#hidden2").hide();
            $("#hidden3").hide();
                    if (Notes === "")
        {
            $('#Notes').val("");
        }
        else
        {
            $('#Notes').val(Notes);
        }
        // var Checked_By = this.getAttribute("checked_by");
        if (Checked_By === "")
        {
            $("#Checked_By_drp").val("");
        }
        else
        {
            $("#Checked_By_drp").val(Checked_By);
        }
        
        // var Received_By = this.getAttribute("received_by");
        if (Received_By === "")
        {
            $("#Received_By_drp").val("");
        }
        else
        {
            $("#Received_By_drp").val(Received_By);
        }
        if (sentdate_formatted === "")
        {
            $('#Sent_Date').val("");
        }
        else
        {
            $('#Sent_Date').val(sent_date);
        }
        if (rec_formatted === "")
        {
            $("#Received_Date").val("");
        }
        else
        {
            $("#Received_Date").val(Received_Date);
        }
        if (req_formatted === "")
        {

            $('#Requested_Date').val(current_date);
        }
        else
        {
            $('#Requested_Date').val(requested_date);
        }
        if (audit_formatted === "")
        {
            $('#Audit_Date').val("");
        }
        else
        {
            $('#Audit_Date').val(audit_date);
        }
    }
    else if (status_val == "Sent for")
    {
        $("#hidden").hide();
        $("#hidden1").hide();
        $("#hidden2").hide();
            $("#hidden3").hide();
                    if (Notes === "")
        {
            $('#Notes').val("");
        }
        else
        {
            $('#Notes').val(Notes);
        }
        // var Checked_By = this.getAttribute("checked_by");
        if (Checked_By === "")
        {
            $("#Checked_By_drp").val("");
        }
        else
        {
            $("#Checked_By_drp").val(Checked_By);
        }
        
        // var Received_By = this.getAttribute("received_by");
        if (Received_By === "")
        {
            $("#Received_By_drp").val("");
        }
        else
        {
            $("#Received_By_drp").val(Received_By);
        }
        if (sentdate_formatted === "")
        {
            $('#Sent_Date').val(current_date);
        }
        else
        {
            $('#Sent_Date').val(sent_date);
        }
        if (rec_formatted === "")
        {
            $("#Received_Date").val("");
        }
        else
        {
            $("#Received_Date").val(Received_Date);
        }
        if (req_formatted === "")
        {

            $('#Requested_Date').val("");
        }
        else
        {
            $('#Requested_Date').val(requested_date);
        }
        if (audit_formatted === "")
        {
            $('#Audit_Date').val("");
        }
        else
        {
            $('#Audit_Date').val(audit_date);
        }
    }
    });

    $("#exampleModal").modal('show');
});
$(document).delegate('.empbtn', 'click', function () {
      $(".btn-sve span").text("Save");
  $(".del_btn").attr("disabled",true);
    $('#recid').val("");
    var status = this.getAttribute("status");
    $('#status').val(status);
    var client_id = this.getAttribute("client_id");
    var client_name = this.getAttribute("client_name");
    $('#dropdownname_cl_popup').attr('clientid',client_id);
    $('#dropdownname_cl_popup').val(client_name);
    var month = this.getAttribute("presentmonth");
    var year = this.getAttribute("presentyear");
    $('#dropdownname_cl_popup').attr('month', month);
    $('#dropdownname_cl_popup').attr('year', year);
       var Notes = this.getAttribute("notes");
    var Checked_By = this.getAttribute("checked_by");
    var Received_By = this.getAttribute("received_by");
    var rec_formatted = this.getAttribute("received_date");
    var Received_Date = moment(rec_formatted).format("YYYY-MM-DD");
    var test = "";
    var checked = "";
    var received = "";
    var rec_date = "";
    var sentdate_formatted = this.getAttribute("sent_date");
    var sent_date = moment(sentdate_formatted).format("YYYY-MM-DD");
    var req_formatted = this.getAttribute("request_date");
    var requested_date = moment(req_formatted).format("YYYY-MM-DD");
    var audit_formatted = this.getAttribute("audit_date");
    var audit_date =  moment(audit_formatted).format("YYYY-MM-DD");
    var current_date = $("#current_date").val();
    $('#status').val(status);
    console.log("testing",requested_date)
    if (status == "Received")
    {
        $("#hidden").show();
        $("#hidden1").show();
        $("#hidden2").show();
        $("#hidden3").show();
        $("#hidden4").hide();
        $("#hidden5").hide();
        $("#hidden6").hide();
        // var Notes = this.getAttribute("notes");
        if (Notes === "")
        {
            $('#Notes').val(test);
        }
        else
        {
            $('#Notes').val(Notes);
        }
        // var Checked_By = this.getAttribute("checked_by");
        if (Checked_By === "")
        {
            $("#Checked_By_drp").val(loginusername);
        }
        else
        {
            $("#Checked_By_drp").val(Checked_By);
        }
        
        // var Received_By = this.getAttribute("received_by");
        if (Received_By === "")
        {
            $("#Received_By_drp").val(loginusername);
        }
        else
        {
            $("#Received_By_drp").val(Received_By);
        }
        if (sentdate_formatted === "")
        {
            $('#Sent_Date').val("");
        }
        else
        {
            $('#Sent_Date').val(sent_date);
        }
        if (rec_formatted === "")
        {
            $("#Received_Date").val(current_date);
        }
        else
        {
            $("#Received_Date").val(Received_Date);
        }
        if (req_formatted === "")
        {

            $('#Requested_Date').val("");
        }
        else
        {
            $('#Requested_Date').val(requested_date);
        }
        if (audit_formatted === "")
        {
            $('#Audit_Date').val("");
        }
        else
        {
            $('#Audit_Date').val(audit_date);
        }
        
    }
    else if (status == "Audit/Scanned")
    {
        $("#hidden").hide();
        $("#hidden1").hide();
        $("#hidden2").hide();
        $("#hidden3").show();
        $("#hidden4").hide();
        $("#hidden5").hide();
        $("#hidden6").show();
        // var Notes = this.getAttribute("notes");
        if (Notes === "")
        {
            $('#Notes').val(test);
        }
        else
        {
            $('#Notes').val(Notes);
        }
        // var Checked_By = this.getAttribute("checked_by");
        if (Checked_By === "")
        {
            $("#Checked_By_drp").val("");
        }
        else
        {
            $("#Checked_By_drp").val(Checked_By);
        }
        
        // var Received_By = this.getAttribute("received_by");
        if (Received_By === "")
        {
            $("#Received_By_drp").val("");
        }
        else
        {
            $("#Received_By_drp").val(Received_By);
        }
        if (sentdate_formatted === "")
        {
            $('#Sent_Date').val("");
        }
        else
        {
            $('#Sent_Date').val(sent_date);
        }
        if (rec_formatted === "")
        {
            $("#Received_Date").val("");
        }
        else
        {
            $("#Received_Date").val(Received_Date);
        }
        if (req_formatted === "")
        {

            $('#Requested_Date').val("");
        }
        else
        {
            $('#Requested_Date').val(requested_date);
        }
        if (audit_formatted === "")
        {
            $('#Audit_Date').val(current_date);
        }
        else
        {
            $('#Audit_Date').val(audit_date);
        }
     
    }
    else if(status == "Requested")
    {
        $("#hidden").hide();
        $("#hidden1").hide();
        $("#hidden2").hide();
        $("#hidden3").hide();
        $("#hidden4").hide();
       $("#hidden5").show();
       $("#hidden6").hide();
        if (Notes === "")
        {
            $('#Notes').val("");
        }
        else
        {
            $('#Notes').val(Notes);
        }
        // var Checked_By = this.getAttribute("checked_by");
        if (Checked_By === "")
        {
            $("#Checked_By_drp").val("");
        }
        else
        {
            $("#Checked_By_drp").val(Checked_By);
        }
        
        // var Received_By = this.getAttribute("received_by");
        if (Received_By === "")
        {
            $("#Received_By_drp").val("");
        }
        else
        {
            $("#Received_By_drp").val(Received_By);
        }
        if (sentdate_formatted === "")
        {
            $('#Sent_Date').val("");
        }
        else
        {
            $('#Sent_Date').val(sent_date);
        }
        if (rec_formatted === "")
        {
            $("#Received_Date").val("");
        }
        else
        {
            $("#Received_Date").val(Received_Date);
        }
        if (req_formatted === "")
        {

            $('#Requested_Date').val(current_date);
        }
        else
        {
            $('#Requested_Date').val(requested_date);
        }
        if (audit_formatted === "")
        {
            $('#Audit_Date').val("");
        }
        else
        {
            $('#Audit_Date').val(audit_date);
        }
    }
    else if (status == "Sent for")
    {
        $("#hidden").hide();
        $("#hidden1").hide();
        $("#hidden2").hide();
        $("#hidden3").hide();
               $("#hidden4").show();
       $("#hidden5").hide();
       $("#hidden6").hide();
        if (Notes === "")
        {
            $('#Notes').val("");
        }
        else
        {
            $('#Notes').val(Notes);
        }
        // var Checked_By = this.getAttribute("checked_by");
        if (Checked_By === "")
        {
            $("#Checked_By_drp").val("");
        }
        else
        {
            $("#Checked_By_drp").val(Checked_By);
        }
        
        // var Received_By = this.getAttribute("received_by");
        if (Received_By === "")
        {
            $("#Received_By_drp").val("");
        }
        else
        {
            $("#Received_By_drp").val(Received_By);
        }
        if (sentdate_formatted === "")
        {
            $('#Sent_Date').val(current_date);
        }
        else
        {
            $('#Sent_Date').val(sent_date);
        }
        if (rec_formatted === "")
        {
            $("#Received_Date").val("");
        }
        else
        {
            $("#Received_Date").val(Received_Date);
        }
        if (req_formatted === "")
        {

            $('#Requested_Date').val("");
        }
        else
        {
            $('#Requested_Date').val(requested_date);
        }
        if (audit_formatted === "")
        {
            $('#Audit_Date').val("");
        }
        else
        {
            $('#Audit_Date').val(audit_date);
        }
    }
 $(document).on("change", "#status", function () {
        var status_val = $('#status').val();
        console.log("status_val", status_val);
        if (status_val == "Received")
        {
            $("#hidden").show();
            $("#hidden1").show();
            $("#hidden2").show();
            $("#hidden3").show();
                   $("#hidden4").hide();
       $("#hidden5").hide();
       $("#hidden6").hide();
        // var Notes = this.getAttribute("notes");
        if (Notes === "")
        {
            $('#Notes').val(test);
        }
        else
        {
            $('#Notes').val(Notes);
        }
        // var Checked_By = this.getAttribute("checked_by");
        if (Checked_By === "")
        {
            $("#Checked_By_drp").val(loginusername);
        }
        else
        {
            $("#Checked_By_drp").val(Checked_By);
        }
        
        // var Received_By = this.getAttribute("received_by");
        if (Received_By === "")
        {
            $("#Received_By_drp").val(loginusername);
        }
        else
        {
            $("#Received_By_drp").val(Received_By);
        }
        if (sentdate_formatted === "")
        {
            $('#Sent_Date').val("");
        }
        else
        {
            $('#Sent_Date').val(sent_date);
        }
        if (rec_formatted === "")
        {
            $("#Received_Date").val(current_date);
        }
        else
        {
            $("#Received_Date").val(Received_Date);
        }
                if (req_formatted === "")
        {

            $('#Requested_Date').val("");
        }
        else
        {
            $('#Requested_Date').val(requested_date);
        }
        if (audit_formatted === "")
        {
            $('#Audit_Date').val("");
        }
        else
        {
            $('#Audit_Date').val(audit_date);
        }
        }
        else if (status_val == "Audit/Scanned")
        {
            $("#hidden").hide();
            $("#hidden1").hide();
            $("#hidden2").hide();
            $("#hidden3").show();
                   $("#hidden4").hide();
       $("#hidden5").hide();
       $("#hidden6").show();
           
        if (Notes === "")
        {
           
            $('#Notes').val(test);
        }
        else
        {
            $('#Notes').val(Notes);
        }
        if (sentdate_formatted === "")
        {
            $('#Sent_Date').val("");
        }
        else
        {
            $('#Sent_Date').val(sent_date);
        }
        if (rec_formatted === "")
        {
            $("#Received_Date").val("");
        }
        else
        {
            $("#Received_Date").val(Received_Date);
        }
        if (req_formatted === "")
        {

            $('#Requested_Date').val("");
        }
        else
        {
            $('#Requested_Date').val(requested_date);
        }
        if (audit_formatted === "")
        {
            $('#Audit_Date').val(current_date);
        }
        else
        {
            $('#Audit_Date').val(audit_date);
        }
        }
    else if(status_val == "Requested")
    {
        $("#hidden").hide();
        $("#hidden1").hide();
        $("#hidden2").hide();
            $("#hidden3").hide();
                   $("#hidden4").hide();
       $("#hidden5").show();
       $("#hidden6").hide();
        if (sentdate_formatted === "")
        {
            $('#Sent_Date').val("");
        }
        else
        {
            $('#Sent_Date').val(sent_date);
        }
        if (rec_formatted === "")
        {
            $("#Received_Date").val("");
        }
        else
        {
            $("#Received_Date").val(Received_Date);
        }
        if (req_formatted === "")
        {

            $('#Requested_Date').val(current_date);
        }
        else
        {
            $('#Requested_Date').val(requested_date);
        }
        if (audit_formatted === "")
        {
            $('#Audit_Date').val("");
        }
        else
        {
            $('#Audit_Date').val(audit_date);
        }
    }
    else if (status_val == "Sent for")
    {
        $("#hidden").hide();
        $("#hidden1").hide();
        $("#hidden2").hide();
            $("#hidden3").hide();
                   $("#hidden4").show();
       $("#hidden5").hide();
       $("#hidden6").hide();
        if (sentdate_formatted === "")
        {
            $('#Sent_Date').val(current_date);
        }
        else
        {
            $('#Sent_Date').val(sent_date);
        }
        if (rec_formatted === "")
        {
            $("#Received_Date").val("");
        }
        else
        {
            $("#Received_Date").val(Received_Date);
        }
        if (req_formatted === "")
        {

            $('#Requested_Date').val("");
        }
        else
        {
            $('#Requested_Date').val(requested_date);
        }
        if (audit_formatted === "")
        {
            $('#Audit_Date').val("");
        }
        else
        {
            $('#Audit_Date').val(audit_date);
        }
    }
    });
 $("#exampleModal").modal('show');
});