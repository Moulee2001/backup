// Get Combined array as for the filter
function generateCombinations(...arrays) {
  const combinations = [];
  function generate(currentCombination, index) {
    if (index === arrays.length) {
      combinations.push(`{${currentCombination.join(', ')}}`);
      return;
    }

    if (arrays[index].length === 0) {
      generate(currentCombination, index + 1);
    } else {
      for (const obj of arrays[index]) {
        const key = Object.keys(obj)[0];
        const value = obj[key];
        generate([...currentCombination, `"${key}": "${value}"`], index + 1);
      }
    }
  }
  generate([], 0);
  return combinations;
}

function removeDuplicatesByKey(array, key) {
  const uniqueKeys = new Set();
  return array.filter(item => {
    const keyValue = item[key];
    if (!uniqueKeys.has(keyValue)) {
      uniqueKeys.add(keyValue);
      return true;
    }
    return false;
  });
}

// ***** Find and Remove Duplicate from emparr list *****
function removeDuplicates(arr, keyProperties) {
  var uniquePairs = new Set();
  var result = [];
  for (var i = 0; i < arr.length; i++) {
    var obj = arr[i];
    var key = keyProperties.map(prop => obj[prop]).join('-');
    if (!uniquePairs.has(key)) {
      uniquePairs.add(key);
      result.push(obj);
    }
  }
  return result;
}
// ***** Find and Remove Duplicate from emparr list ends *****

// check hasOwnProperty
function checkProperties(obj, properties) {
  for (var i = 0; i < properties.length; i++) {
    if (!obj.hasOwnProperty(properties[i])) {
      return false;
    }
  }
  return true;
}
// check hasOwnProperty ends

function searchRecord(marsData,monthdata,yearData,empName) {
  const filteredItems = marsData.filter(item => {
    const startDate = item.schstartdt;
    const endDate=new Date(item.schenddt);
    return item.month === monthdata && item.year === yearData && item.client_id === empName
  });

  return filteredItems;
}
function searchRecord_With_Filter(marsData, ClientName,CareFaciName, monthdata,yearData,value) {
//   var searchDate1 = new Date(SearchDate);
  const filteredItems = marsData.filter(item => {
    const startDate = new Date(item.schstartdt);
    const endDate=new Date(item.schenddt);
    // const clientval=item.client.trim();
    if (CareFaciName!=0 && ClientName!=0 && value == 0) {
      return item.month === monthdata && item.year === yearData && item.client_id === ClientName && item.care_factiliter ==CareFaciName
    }
    else if (CareFaciName!=0 && value == 1)
    {
      return item.month === monthdata && item.year === yearData && item.care_factiliter ==CareFaciName && item.client_id === ClientName
    }
    else if(ClientName!=0 && value == 0)
    {
        return item.month === monthdata && item.year === yearData && item.client_id === ClientName
    }
  });
  return filteredItems;
}
// Create New Array with unique value
function filterObjectsByCarerName(arr, arr1) {
  return arr1.filter(function(obj) {
    return !arr.some(function(obj2) {
      return obj2.EmpName === obj.client;
    });
  });
}
// Create New Array with unique value ends here
// Function to group items by carerName
function groupByCarerName(data) {
  var groupedArrays = {};

  data.forEach(function(item) {
      var carerName = item.clientName;

      if (!groupedArrays[carerName]) {
          // If the array for the carerName does not exist, create a new one
          groupedArrays[carerName] = [];
      }

      // Push the item into the corresponding array
      groupedArrays[carerName].push(item);
  });

  return groupedArrays;
}