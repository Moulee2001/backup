
$(document).delegate('.empdiv', 'click', function () {
      $(".btn-sve span").text("Update");
  $(".del_btn").attr("disabled",false);
    var Emp_Recid = this.getAttribute("rec_id");
    var status = this.getAttribute("status");
    $('#recid').val(Emp_Recid);
    // var rowData = $(this).closest("tr");
    var client_id = this.getAttribute("client_id");
    var client_name = this.getAttribute("client_name");
    $('#dropdownname_cl_popup').attr('clientid',client_id);
    $('#dropdownname_cl_popup').val(client_name);
    var month = this.getAttribute("presentmonth");
    var year = this.getAttribute("presentyear");
    $('#dropdownname_cl_popup').attr('month', month);
    $('#dropdownname_cl_popup').attr('year', year);
    var Notes = this.getAttribute("notes");
    var Checked_By = this.getAttribute("checked_by");
    var Case_Manager = this.getAttribute("case_manager");
    var test = "";
    var checked = "";
    var received = "";
    var rec_date = "";
    var visitdate_formatted = this.getAttribute("visit_date");
    var visit_date = moment(visitdate_formatted).format("YYYY-MM-DD");
    var orgdate_formatted = this.getAttribute("organised_date");
    var org_date = moment(orgdate_formatted).format("YYYY-MM-DD");
    var current_date = $("#current_date").val();
    $('#status').val(status);
    if (status == "Due")
    {
           $("#checked_by").hide();
           $("#case_manager").hide();
           $("#visit_date").show();
           $("#organised_date").hide();
           $("#notes").show(); 
        if (Notes === "")
        {
            $('#Notes').val("");
        }
        else
        {
            $('#Notes').val(Notes);
        } 
        if (Checked_By === "")
        {
            $("#Checked_By_drp").val("");
        }
        else
        {
            $("#Checked_By_drp").val(Checked_By);
        }
        if (Case_Manager === "")
        {
            $("#Case_Manager_drp").val("");
        }
        else
        {
            $("#Case_Manager_drp").val(Case_Manager);
        }
        if (visitdate_formatted === "")
        {
            $('#Visit_Date').val(current_date);
        }
        else
        {
            $('#Visit_Date').val(visit_date);
        }
        if (orgdate_formatted === "")
        {
            $("#Organised_Date").val("");
        }
        else
        {
            $("#Organised_Date").val(org_date);
        }
    }
    else if (status == "Organised")
    {
           $("#checked_by").show();
           $("#case_manager").show();
           $("#visit_date").hide();
           $("#organised_date").show();
           $("#notes").show(); 
        if (Notes === "")
        {
            $('#Notes').val("");
        }
        else
        {
            $('#Notes').val(Notes);
        } 
        if (Checked_By === "")
        {
            $("#Checked_By_drp").val(loginusername);
        }
        else
        {
            $("#Checked_By_drp").val(Checked_By);
        }
        if (Case_Manager === "")
        {
            $("#Case_Manager_drp").val(loginusername);
        }
        else
        {
            $("#Case_Manager_drp").val(Case_Manager);
        }
        if (visitdate_formatted === "")
        {
            $('#Visit_Date').val("");
        }
        else
        {
            $('#Visit_Date').val(visit_date);
        }
        if (orgdate_formatted === "")
        {
            $("#Organised_Date").val(current_date);
        }
        else
        {
            $("#Organised_Date").val(org_date);
        }
    }
    else if (status == "Completed")
    {
           $("#checked_by").hide();
           $("#case_manager").hide();
           $("#visit_date").hide();
           $("#organised_date").hide();
          $("#notes").show();
        if (Notes === "")
        {
            $('#Notes').val("");
        }
        else
        {
            $('#Notes').val(Notes);
        } 
        if (Checked_By === "")
        {
            $("#Checked_By_drp").val("");
        }
        else
        {
            $("#Checked_By_drp").val(Checked_By);
        }
        if (Case_Manager === "")
        {
            $("#Case_Manager_drp").val("");
        }
        else
        {
            $("#Case_Manager_drp").val(Case_Manager);
        }
        if (visitdate_formatted === "")
        {
            $('#Visit_Date').val("");
        }
        else
        {
            $('#Visit_Date').val(visit_date);
        }
        if (orgdate_formatted === "")
        {
            $("#Organised_Date").val("");
        }
        else
        {
            $("#Organised_Date").val(org_date);
        }
    }
    else if (status == "Cancelled")
    {
           $("#checked_by").hide();
           $("#case_manager").hide();
           $("#visit_date").hide();
           $("#organised_date").hide();
            $("#notes").hide();
        if (Notes === "")
        {
            $('#Notes').val("");
        }
        else
        {
            $('#Notes').val(Notes);
        } 
        if (Checked_By === "")
        {
            $("#Checked_By_drp").val("");
        }
        else
        {
            $("#Checked_By_drp").val(Checked_By);
        }
        if (Case_Manager === "")
        {
            $("#Case_Manager_drp").val("");
        }
        else
        {
            $("#Case_Manager_drp").val(Case_Manager);
        }
        if (visitdate_formatted === "")
        {
            $('#Visit_Date').val("");
        }
        else
        {
            $('#Visit_Date').val(visit_date);
        }
        if (orgdate_formatted === "")
        {
            $("#Organised_Date").val("");
        }
        else
        {
            $("#Organised_Date").val(org_date);
        }        

    }
    else if (status == "Not Started")
    {
           $("#checked_by").hide();
           $("#case_manager").hide();
           $("#visit_date").hide();
           $("#organised_date").hide();
        $("#notes").hide();
        if (Notes === "")
        {
            $('#Notes').val("");
        }
        else
        {
            $('#Notes').val(Notes);
        } 
        if (Checked_By === "")
        {
            $("#Checked_By_drp").val("");
        }
        else
        {
            $("#Checked_By_drp").val(Checked_By);
        }
        if (Case_Manager === "")
        {
            $("#Case_Manager_drp").val("");
        }
        else
        {
            $("#Case_Manager_drp").val(Case_Manager);
        }
        if (visitdate_formatted === "")
        {
            $('#Visit_Date').val("");
        }
        else
        {
            $('#Visit_Date').val(visit_date);
        }
        if (orgdate_formatted === "")
        {
            $("#Organised_Date").val("");
        }
        else
        {
            $("#Organised_Date").val(org_date);
        }
        
    }
    $(document).on("change", "#status", function () {
        var status_val = $('#status').val();
        console.log("status_val", status_val);
    if (status_val == "Due")
    {
           $("#checked_by").hide();
           $("#case_manager").hide();
           $("#visit_date").show();
           $("#organised_date").hide();
           $("#notes").show(); 
        if (Notes === "")
        {
            $('#Notes').val("");
        }
        else
        {
            $('#Notes').val(Notes);
        } 
        if (Checked_By === "")
        {
            $("#Checked_By_drp").val("");
        }
        else
        {
            $("#Checked_By_drp").val(Checked_By);
        }
        if (Case_Manager === "")
        {
            $("#Case_Manager_drp").val("");
        }
        else
        {
            $("#Case_Manager_drp").val(Case_Manager);
        }
        if (visitdate_formatted === "")
        {
            $('#Visit_Date').val(current_date);
        }
        else
        {
            $('#Visit_Date').val(visit_date);
        }
        if (orgdate_formatted === "")
        {
            $("#Organised_Date").val("");
        }
        else
        {
            $("#Organised_Date").val(org_date);
        }
    }
    else if (status_val == "Organised")
    {
           $("#checked_by").show();
           $("#case_manager").show();
           $("#visit_date").hide();
           $("#organised_date").show();
           $("#notes").show(); 
        if (Notes === "")
        {
            $('#Notes').val("");
        }
        else
        {
            $('#Notes').val(Notes);
        } 
        if (Checked_By === "")
        {
            $("#Checked_By_drp").val(loginusername);
        }
        else
        {
            $("#Checked_By_drp").val(Checked_By);
        }
        if (Case_Manager === "")
        {
            $("#Case_Manager_drp").val(loginusername);
        }
        else
        {
            $("#Case_Manager_drp").val(Case_Manager);
        }
        if (visitdate_formatted === "")
        {
            $('#Visit_Date').val("");
        }
        else
        {
            $('#Visit_Date').val(visit_date);
        }
        if (orgdate_formatted === "")
        {
            $("#Organised_Date").val(current_date);
        }
        else
        {
            $("#Organised_Date").val(org_date);
        }
    }
    else if (status_val == "Completed")
    {
           $("#checked_by").hide();
           $("#case_manager").hide();
           $("#visit_date").hide();
           $("#organised_date").hide();
          $("#notes").show();
        if (Notes === "")
        {
            $('#Notes').val("");
        }
        else
        {
            $('#Notes').val(Notes);
        } 
        if (Checked_By === "")
        {
            $("#Checked_By_drp").val("");
        }
        else
        {
            $("#Checked_By_drp").val(Checked_By);
        }
        if (Case_Manager === "")
        {
            $("#Case_Manager_drp").val("");
        }
        else
        {
            $("#Case_Manager_drp").val(Case_Manager);
        }
        if (visitdate_formatted === "")
        {
            $('#Visit_Date').val("");
        }
        else
        {
            $('#Visit_Date').val(visit_date);
        }
        if (orgdate_formatted === "")
        {
            $("#Organised_Date").val("");
        }
        else
        {
            $("#Organised_Date").val(org_date);
        }
    }
    else if (status_val == "Cancelled")
    {
           $("#checked_by").hide();
           $("#case_manager").hide();
           $("#visit_date").hide();
           $("#organised_date").hide();
            $("#notes").hide();
        if (Notes === "")
        {
            $('#Notes').val("");
        }
        else
        {
            $('#Notes').val(Notes);
        } 
        if (Checked_By === "")
        {
            $("#Checked_By_drp").val("");
        }
        else
        {
            $("#Checked_By_drp").val(Checked_By);
        }
        if (Case_Manager === "")
        {
            $("#Case_Manager_drp").val("");
        }
        else
        {
            $("#Case_Manager_drp").val(Case_Manager);
        }
        if (visitdate_formatted === "")
        {
            $('#Visit_Date').val("");
        }
        else
        {
            $('#Visit_Date').val(visit_date);
        }
        if (orgdate_formatted === "")
        {
            $("#Organised_Date").val("");
        }
        else
        {
            $("#Organised_Date").val(org_date);
        }        

    }
    else if (status_val == "Not Started")
    {
           $("#checked_by").hide();
           $("#case_manager").hide();
           $("#visit_date").hide();
           $("#organised_date").hide();
        $("#notes").hide();
        if (Notes === "")
        {
            $('#Notes').val("");
        }
        else
        {
            $('#Notes').val(Notes);
        } 
        if (Checked_By === "")
        {
            $("#Checked_By_drp").val("");
        }
        else
        {
            $("#Checked_By_drp").val(Checked_By);
        }
        if (Case_Manager === "")
        {
            $("#Case_Manager_drp").val("");
        }
        else
        {
            $("#Case_Manager_drp").val(Case_Manager);
        }
        if (visitdate_formatted === "")
        {
            $('#Visit_Date').val("");
        }
        else
        {
            $('#Visit_Date').val(visit_date);
        }
        if (orgdate_formatted === "")
        {
            $("#Organised_Date").val("");
        }
        else
        {
            $("#Organised_Date").val(org_date);
        }
        
    }
    });

    $("#exampleModal").modal('show');
});
$(document).delegate('.empbtn', 'click', function () {
      $(".btn-sve span").text("Save");
  $(".del_btn").attr("disabled",true);
    $('#recid').val("");
    var status = this.getAttribute("status");
    $('#status').val(status);
    var client_id = this.getAttribute("client_id");
    var client_name = this.getAttribute("client_name");
    $('#dropdownname_cl_popup').attr('clientid',client_id);
    $('#dropdownname_cl_popup').val(client_name);
    var month = this.getAttribute("presentmonth");
    var year = this.getAttribute("presentyear");
    $('#dropdownname_cl_popup').attr('month', month);
    $('#dropdownname_cl_popup').attr('year', year);
       var Notes = this.getAttribute("notes");
    var Checked_By = this.getAttribute("checked_by");
    var Case_Manager = this.getAttribute("case_manager");
    var test = "";
    var checked = "";
    var received = "";
    var rec_date = "";
    var visitdate_formatted = this.getAttribute("visit_date");
    var visit_date = moment(visitdate_formatted).format("YYYY-MM-DD");
    var orgdate_formatted = this.getAttribute("organised_date");
    var org_date = moment(orgdate_formatted).format("YYYY-MM-DD");
    var current_date = $("#current_date").val();
    $('#status').val(status);
    if (status == "Due")
    {
           $("#checked_by").hide();
           $("#case_manager").hide();
           $("#visit_date").show();
           $("#organised_date").hide();
           $("#notes").show(); 
        if (Notes === "")
        {
            $('#Notes').val("");
        }
        else
        {
            $('#Notes').val(Notes);
        } 
        if (Checked_By === "")
        {
            $("#Checked_By_drp").val("");
        }
        else
        {
            $("#Checked_By_drp").val(Checked_By);
        }
        if (Case_Manager === "")
        {
            $("#Case_Manager_drp").val("");
        }
        else
        {
            $("#Case_Manager_drp").val(Case_Manager);
        }
        if (visitdate_formatted === "")
        {
            $('#Visit_Date').val(current_date);
        }
        else
        {
            $('#Visit_Date').val(visit_date);
        }
        if (orgdate_formatted === "")
        {
            $("#Organised_Date").val("");
        }
        else
        {
            $("#Organised_Date").val(org_date);
        }
    }
    else if (status == "Organised")
    {
           $("#checked_by").show();
           $("#case_manager").show();
           $("#visit_date").hide();
           $("#organised_date").show();
           $("#notes").show(); 
        if (Notes === "")
        {
            $('#Notes').val("");
        }
        else
        {
            $('#Notes').val(Notes);
        } 
        if (Checked_By === "")
        {
            $("#Checked_By_drp").val(loginusername);
        }
        else
        {
            $("#Checked_By_drp").val(Checked_By);
        }
        if (Case_Manager === "")
        {
            $("#Case_Manager_drp").val(loginusername);
        }
        else
        {
            $("#Case_Manager_drp").val(Case_Manager);
        }
        if (visitdate_formatted === "")
        {
            $('#Visit_Date').val("");
        }
        else
        {
            $('#Visit_Date').val(visit_date);
        }
        if (orgdate_formatted === "")
        {
            $("#Organised_Date").val(current_date);
        }
        else
        {
            $("#Organised_Date").val(org_date);
        }
    }
    else if (status == "Completed")
    {
           $("#checked_by").hide();
           $("#case_manager").hide();
           $("#visit_date").hide();
           $("#organised_date").hide();
          $("#notes").show();
        if (Notes === "")
        {
            $('#Notes').val("");
        }
        else
        {
            $('#Notes').val(Notes);
        } 
        if (Checked_By === "")
        {
            $("#Checked_By_drp").val("");
        }
        else
        {
            $("#Checked_By_drp").val(Checked_By);
        }
        if (Case_Manager === "")
        {
            $("#Case_Manager_drp").val("");
        }
        else
        {
            $("#Case_Manager_drp").val(Case_Manager);
        }
        if (visitdate_formatted === "")
        {
            $('#Visit_Date').val("");
        }
        else
        {
            $('#Visit_Date').val(visit_date);
        }
        if (orgdate_formatted === "")
        {
            $("#Organised_Date").val("");
        }
        else
        {
            $("#Organised_Date").val(org_date);
        }
    }
    else if (status == "Cancelled")
    {
           $("#checked_by").hide();
           $("#case_manager").hide();
           $("#visit_date").hide();
           $("#organised_date").hide();
            $("#notes").hide();
        if (Notes === "")
        {
            $('#Notes').val("");
        }
        else
        {
            $('#Notes').val(Notes);
        } 
        if (Checked_By === "")
        {
            $("#Checked_By_drp").val("");
        }
        else
        {
            $("#Checked_By_drp").val(Checked_By);
        }
        if (Case_Manager === "")
        {
            $("#Case_Manager_drp").val("");
        }
        else
        {
            $("#Case_Manager_drp").val(Case_Manager);
        }
        if (visitdate_formatted === "")
        {
            $('#Visit_Date').val("");
        }
        else
        {
            $('#Visit_Date').val(visit_date);
        }
        if (orgdate_formatted === "")
        {
            $("#Organised_Date").val("");
        }
        else
        {
            $("#Organised_Date").val(org_date);
        }        

    }
    else if (status == "Not Started")
    {
           $("#checked_by").hide();
           $("#case_manager").hide();
           $("#visit_date").hide();
           $("#organised_date").hide();
        $("#notes").hide();
        if (Notes === "")
        {
            $('#Notes').val("");
        }
        else
        {
            $('#Notes').val(Notes);
        } 
        if (Checked_By === "")
        {
            $("#Checked_By_drp").val("");
        }
        else
        {
            $("#Checked_By_drp").val(Checked_By);
        }
        if (Case_Manager === "")
        {
            $("#Case_Manager_drp").val("");
        }
        else
        {
            $("#Case_Manager_drp").val(Case_Manager);
        }
        if (visitdate_formatted === "")
        {
            $('#Visit_Date').val("");
        }
        else
        {
            $('#Visit_Date').val(visit_date);
        }
        if (orgdate_formatted === "")
        {
            $("#Organised_Date").val("");
        }
        else
        {
            $("#Organised_Date").val(org_date);
        }
        
    }
    $(document).on("change", "#status", function () {
        var status_val = $('#status').val();
        console.log("status_val", status_val);
    if (status_val == "Due")
    {
           $("#checked_by").hide();
           $("#case_manager").hide();
           $("#visit_date").show();
           $("#organised_date").hide();
           $("#notes").show(); 
        if (Notes === "")
        {
            $('#Notes').val("");
        }
        else
        {
            $('#Notes').val(Notes);
        } 
        if (Checked_By === "")
        {
            $("#Checked_By_drp").val("");
        }
        else
        {
            $("#Checked_By_drp").val(Checked_By);
        }
        if (Case_Manager === "")
        {
            $("#Case_Manager_drp").val("");
        }
        else
        {
            $("#Case_Manager_drp").val(Case_Manager);
        }
        if (visitdate_formatted === "")
        {
            $('#Visit_Date').val(current_date);
        }
        else
        {
            $('#Visit_Date').val(visit_date);
        }
        if (orgdate_formatted === "")
        {
            $("#Organised_Date").val("");
        }
        else
        {
            $("#Organised_Date").val(org_date);
        }
    }
    else if (status_val == "Organised")
    {
           $("#checked_by").show();
           $("#case_manager").show();
           $("#visit_date").hide();
           $("#organised_date").show();
           $("#notes").show(); 
        if (Notes === "")
        {
            $('#Notes').val("");
        }
        else
        {
            $('#Notes').val(Notes);
        } 
        if (Checked_By === "")
        {
            $("#Checked_By_drp").val(loginusername);
        }
        else
        {
            $("#Checked_By_drp").val(Checked_By);
        }
        if (Case_Manager === "")
        {
            $("#Case_Manager_drp").val(loginusername);
        }
        else
        {
            $("#Case_Manager_drp").val(Case_Manager);
        }
        if (visitdate_formatted === "")
        {
            $('#Visit_Date').val("");
        }
        else
        {
            $('#Visit_Date').val(visit_date);
        }
        if (orgdate_formatted === "")
        {
            $("#Organised_Date").val(current_date);
        }
        else
        {
            $("#Organised_Date").val(org_date);
        }
    }
    else if (status_val == "Completed")
    {
           $("#checked_by").hide();
           $("#case_manager").hide();
           $("#visit_date").hide();
           $("#organised_date").hide();
          $("#notes").show();
        if (Notes === "")
        {
            $('#Notes').val("");
        }
        else
        {
            $('#Notes').val(Notes);
        } 
        if (Checked_By === "")
        {
            $("#Checked_By_drp").val("");
        }
        else
        {
            $("#Checked_By_drp").val(Checked_By);
        }
        if (Case_Manager === "")
        {
            $("#Case_Manager_drp").val("");
        }
        else
        {
            $("#Case_Manager_drp").val(Case_Manager);
        }
        if (visitdate_formatted === "")
        {
            $('#Visit_Date').val("");
        }
        else
        {
            $('#Visit_Date').val(visit_date);
        }
        if (orgdate_formatted === "")
        {
            $("#Organised_Date").val("");
        }
        else
        {
            $("#Organised_Date").val(org_date);
        }
    }
    else if (status_val == "Cancelled")
    {
           $("#checked_by").hide();
           $("#case_manager").hide();
           $("#visit_date").hide();
           $("#organised_date").hide();
            $("#notes").hide();
        if (Notes === "")
        {
            $('#Notes').val("");
        }
        else
        {
            $('#Notes').val(Notes);
        } 
        if (Checked_By === "")
        {
            $("#Checked_By_drp").val("");
        }
        else
        {
            $("#Checked_By_drp").val(Checked_By);
        }
        if (Case_Manager === "")
        {
            $("#Case_Manager_drp").val("");
        }
        else
        {
            $("#Case_Manager_drp").val(Case_Manager);
        }
        if (visitdate_formatted === "")
        {
            $('#Visit_Date').val("");
        }
        else
        {
            $('#Visit_Date').val(visit_date);
        }
        if (orgdate_formatted === "")
        {
            $("#Organised_Date").val("");
        }
        else
        {
            $("#Organised_Date").val(org_date);
        }        

    }
    else if (status_val == "Not Started")
    {
           $("#checked_by").hide();
           $("#case_manager").hide();
           $("#visit_date").hide();
           $("#organised_date").hide();
        $("#notes").hide();
        if (Notes === "")
        {
            $('#Notes').val("");
        }
        else
        {
            $('#Notes').val(Notes);
        } 
        if (Checked_By === "")
        {
            $("#Checked_By_drp").val("");
        }
        else
        {
            $("#Checked_By_drp").val(Checked_By);
        }
        if (Case_Manager === "")
        {
            $("#Case_Manager_drp").val("");
        }
        else
        {
            $("#Case_Manager_drp").val(Case_Manager);
        }
        if (visitdate_formatted === "")
        {
            $('#Visit_Date').val("");
        }
        else
        {
            $('#Visit_Date').val(visit_date);
        }
        if (orgdate_formatted === "")
        {
            $("#Organised_Date").val("");
        }
        else
        {
            $("#Organised_Date").val(org_date);
        }
        
    }
    });
 $("#exampleModal").modal('show');
});