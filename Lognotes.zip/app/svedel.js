$(document).delegate('.btn-sve', 'click', function () {
  $(".btn-sve").attr("disabled", true);
  var Emp_Recid = $("#recid").val();
  var client_id = $('#dropdownname_cl_popup').attr('clientid');
  console.log(client_id);
  var status = $("#status option:selected").attr("value");
  var Received_Date = $("#Received_Date").val() || "";
  var Sent_for_Date = $("#Sent_Date").val() || "";
  var Requested_Date = $("#Requested_Date").val()||"";
    var Audit_Scanned_Date = $("#Audit_Date").val()||"";
    var Current_date = $("#current_date").val();
    var notes = $("#Notes").val();
    var month = $('#dropdownname_cl_popup').attr("month");
    var year = $('#dropdownname_cl_popup').attr("year");
    var recby = $("#Received_By_drp option:selected").attr("value");
    var checkby = $("#Checked_By_drp option:selected").attr("value");
    if(Emp_Recid != "")
    {
      marsDataupdate = {
      "data" : {
      "Clients": client_id,
      "Received_Date": Received_Date ? moment(Received_Date).format("DD-MMM-YYYY") : "",
      "Sent_for_Date": Sent_for_Date ? moment(Sent_for_Date).format("DD-MMM-YYYY") : "",
      "Requested_Date": Requested_Date ? moment(Requested_Date).format("DD-MMM-YYYY") : "",
      "Audit_Scanned_Date": Audit_Scanned_Date ? moment(Audit_Scanned_Date).format("DD-MMM-YYYY") : "",
      "Status": status,
      "Notes":notes,
      "Month_field":month,
      "Year_field": year,
      "Checked_By": checkby,
      "Received_By":recby
      }
      }

    var marsconfigupdate = {    
      appName : "hcd-admin",
      reportName:"Log_Notes_Report",
      id:Emp_Recid,
      data : marsDataupdate
        }
        ZOHO.CREATOR.API.updateRecord(marsconfigupdate).then(function (marsresponseupdate) {
            console.log("marsresponseupdate", marsresponseupdate.data);
        if(marsresponseupdate.code == 3000){
            $("#exampleModal").modal("hide");
            marsDataArr=[];
            VisitSchedule_Func().then(ReturnVal=>{
              DisplayShiftDetails_Func();
            });
            console.log("Record added successfully");
            Swal.fire({
              title: "Record Updated successfully",
              icon: "success",
              showConfirmButton :false,
              timer: 1000
            });
            }
        else
          {
            Swal.fire({
              title: "Record not Updated successfully",
              icon: "error",
              showConfirmButton :false,
              timer: 1000
            });
          }
          $(".btn-sve").prop("disabled",false);
        });
    }
    else if (Emp_Recid == "")
    {
      marsformData = {
        "data": {
      "Clients": client_id,
      "Received_Date": Received_Date ? moment(Received_Date).format("DD-MMM-YYYY") : "",
      "Sent_for_Date": Sent_for_Date ? moment(Sent_for_Date).format("DD-MMM-YYYY") : "",
      "Requested_Date": Requested_Date ? moment(Requested_Date).format("DD-MMM-YYYY") : "",
      "Audit_Scanned_Date": Audit_Scanned_Date ? moment(Audit_Scanned_Date).format("DD-MMM-YYYY") : "",
      "Status": status,
      "Notes":notes,
      "Month_field":month,
      "Year_field": year,
      "Checked_By": checkby,
      "Received_By":recby
        }
      }
    var marsconfig = {    
      appName : "hcd-admin",
      formName :"Log_Notes",
      data : marsformData
        }   
        ZOHO.CREATOR.API.addRecord(marsconfig).then(function(marstresponse){
          console.log("newshiftresponse:",marstresponse);
          if(marstresponse.code == 3000){
            $("#exampleModal").modal("hide");
            marsDataArr=[];
            VisitSchedule_Func().then(ReturnVal=>{
              DisplayShiftDetails_Func();
            });
            Swal.fire({
              title: "Record added successfully",
              icon: "success",
              showConfirmButton :false,
              timer: 1000
            });
          }
          else
          {
            Swal.fire({
              title: "Record not added successfully",
              icon: "error",
              showConfirmButton :false,
              timer: 1000
            });
          }
          $(".btn-sve").prop("disabled",false);
        });  
    }
});
$(document).delegate('.del_btn', 'click', function () {
  var Emp_Recid = $("#recid").val();
    $(".del_btn").attr("disabled",true);
  console.log("Hi i'm dlt btn");
      var config_delete = { 
    appName : "hcd-admin",
    reportName :"Log_Notes_Report",
    criteria : '(ID == '+Emp_Recid+')'
  } 
  ZOHO.CREATOR.API.deleteRecord(config_delete).then(function(response_delete){
      console.log("Record has been deleted");

      if(response_delete.code == 3000){
        console.log("Record deleted successfully");
        $("#exampleModal").modal("hide");
        marsDataArr=[];
        VisitSchedule_Func().then(ReturnVal=>{
          DisplayShiftDetails_Func();
        });
        Swal.fire({
          title: "Record Deleted successfully",
          icon: "success",
          showConfirmButton :false,
          timer: 1500
        });
      }
      else
      {
        Swal.fire({
          title: "Error Occurred While Deleting Records...!",
          icon: "error",
          showConfirmButton :false,
          timer: 1500
        });
      }
    $(".del_btn").attr("disabled",false); 
  });
  $(".del_btn").attr("disabled",true); 
});