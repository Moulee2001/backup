var wholeCareClient=[];

async function DisplayFilterData_Func() {
    try {
        const ClientFilterReport = Client_Filter_Func();
        const clientcarerReport = ClientCarer_Filter_Func();
        const VisitScheduleReport = VisitSchedule_Func();
        const Marssetting = Mars_Func();
        const clientCarer_Result = await Promise.all([clientcarerReport]);
        const ClientResult = await Promise.all([ClientFilterReport]);
        


            const uniqueClientNames = [...new Set(clientCarer_Result[0].map(item => item.clientName))]; // function to extract unique ClientNames 
        console.log("uniqueClientNames:", uniqueClientNames);
        

            // Function to filter the carer unique data
    function filterData(data, data1) {
      return data.filter(item => data1.includes(item.clientName));
        }
        const filteredData = filterData(ClientResult[0], uniqueClientNames);
        console.log("filteredData", filteredData);
            for(var index in filteredData){
      var rec_id = filteredData[index].clientID;
      var clientName = filteredData[index].clientName;  
      
      $('.clientdataDD').append($('<option>', {
        value: rec_id,
        text: clientName,
        'cl_rec_id':rec_id,  // Example additional attribute
        'client_name': clientName   // Another example additional attribute
      }));
    }
            // Client Carer Function
    // const uniqueCareFaciNames = [...new Set(clientCarer_Result[0].map(item => item.careFaciName))];
    const uniqueCareFaciNames = clientCarer_Result[0] ? [...new Set(clientCarer_Result[0].map(item => item.careFaciName))].filter(name => name !== "") : [];
      console.log("uniqueCareFaciNames", uniqueCareFaciNames);
        uniqueCareFaciNames.forEach(resultdata => {
      $('.carefacidataDD').append($('<option>', {
        value: resultdata,
        text: resultdata,
        'care_facilitier_name':resultdata
      }));
        $('#Received_By_drp').append($('<option>', {
        value: resultdata,
        text: resultdata,
        'care_facilitier_name':resultdata
             }));
        $('#Checked_By_drp').append($('<option>', {
        value: resultdata,
        text: resultdata,
        'care_facilitier_name':resultdata
      }));
    });
    // *****************************************************************************
        clientArr = filteredData;// push data into clientArr
        const result = await Promise.all([VisitScheduleReport]);
    return result;
    }
     catch (error) {
    console.error('Error:', error);
    }
}
async function ClientCarer_Filter_Func() {
  var returnVal=null;
  var ClientCarerList=[];
  try{
    const ClientCarer_Response = await ZOHO.CREATOR.API.getAllRecords({ 
      appName : "hcd-admin",
      reportName : "Clients_Report",
      page : 1
    });
    const recordArr = await ClientCarer_Response.data;
    console.log("ClientCarer_Response:",recordArr);
      for (var index in recordArr) {

       var ClientName = recordArr[index].Name.display_value.trim();
         var clientID = recordArr[index].ID;
          var careFaciName = recordArr[index].Care_Facilitator;
          console.log("careFaciName", ClientName);
      ClientCarerList.push({
        "careFaciName":careFaciName,
        "clientName":ClientName,
        "clientID":clientID,
      });
    }
    const uniqueArrayvalue = [...new Set(ClientCarerList)];
      wholeCareClient = uniqueArrayvalue;
      console.log("wholeCareClient", wholeCareClient);

  }catch(error){
    console.log("error",error);
  }
  console.log("ClientCarerList:",ClientCarerList);
  return ClientCarerList;
}
async function Client_Filter_Func() {
  var clientList=[];
  try
  {
    const clinet_response = await ZOHO.CREATOR.API.getAllRecords({
      reportName : "Clients_Report",  
      page : 1
    });
    const clientrecordArr = await clinet_response.data;
    for(var cliindex in clientrecordArr){
      var recid=clientrecordArr[cliindex].ID;
      clientList.push({
        "clientID":clientrecordArr[cliindex].ID,
        "clientName":clientrecordArr[cliindex].Name.display_value
      });
    }
  }catch (error)
  {
    console.log("error found:",error);
  }
//   console.log("clientList:",clientList);
  return clientList;
}
async function VisitSchedule_Func() {
  var emplist=[];
  for (let i = 1; i <=10; i++)
  {
    var Visitconfig = { 
      appName : "hcd-admin",
      reportName :"Log_Notes_Report", 
      page : i
    }
    try{
      const cust_response = await ZOHO.CREATOR.API.getAllRecords(Visitconfig);
      const recordArr = await cust_response.data;
    //   console.log("recordArr visit:",recordArr);
        for (var index in recordArr) {
            console.log("data", recordArr[index]);
            var clientData = recordArr[index].Clients.display_value;
            var client_id = recordArr[index].Clients.ID;
            var month = recordArr[index].Month_field;
            var year = recordArr[index].Year_field;
            var rec_date = recordArr[index].Received_Date;
            var rec_id = recordArr[index].ID;
            var care_facilitators = recordArr[index]["Clients.Care_Facilitator"];
          var Status = recordArr[index].Status;
          var Checkby = recordArr[index].Checked_By;
          var Receivedby = recordArr[index].Received_By;
          var Notes = recordArr[index].Notes;
          var Sent_for_Date = recordArr[index].Sent_for_Date;
          marsDataArr.push(
              {
                  "client_id": client_id,
                  "client": clientData,
                  "month": month,
                  "year": year,
                  "rec_date": rec_date,
                  "care_factiliter": care_facilitators,
                  "Status":Status,
                  "rec_id": rec_id,
                  "Checked_By":Checkby,
                  "Received_By": Receivedby,
                  "Notes": Notes,
                  "Sent_for_Date": Sent_for_Date
              }
          );
      }
    } catch (error){
      console.log("error:", error);
      return false;
    }
  }
  // Your code here
  return emplist;
}


async function Mars_Func() {
        mars_config = {
        appName : "hcd-admin",
        reportName : "LogNotes_Settings_Report",
        page :1,
        pageSize : 10
    }
        try{
      const mars_response = await ZOHO.CREATOR.API.getAllRecords(mars_config);
          const mars_recordArr = await mars_response.data;
          for (var index in mars_recordArr) {
                console.log("new value",mars_recordArr[index])
           var subformrec=mars_recordArr[index].Settings;
for (var subindex in subformrec) {
    var str = subformrec[subindex].display_value;
    var parts = str.split(',');
    var Action = parts[0];
    var color = parts[1];
    actionColorMap[Action] = color;

    var innerDiv = document.createElement('div');
    innerDiv.innerHTML = Action;
    innerDiv.style.padding = '20px';

    // Create the Font Awesome icon element
    var colorIcon = document.createElement('i');
    colorIcon.style.fontSize = '15px';
    colorIcon.className = 'fa fa-circle'; // Using the Font Awesome class for a circle
    colorIcon.style.color = color;
    colorIcon.style.marginLeft = '-10px'; // margin between text and icon

    var wrapperDiv = document.createElement('div');
    wrapperDiv.style.display = 'flex';
    wrapperDiv.style.alignItems = 'center';
    wrapperDiv.style.marginLeft = '20px'; // Adjust if needed

    wrapperDiv.appendChild(innerDiv);
    wrapperDiv.appendChild(colorIcon);
    outerDiv.appendChild(wrapperDiv);
}
            }	

    } catch (error){
      console.log("error:", error);
      return false;
    }
}

// async function login_Func() {
//     var initparams =await ZOHO.CREATOR.UTIL.getQueryParams();
//   console.log("initparams:", initparams);
//   loginusername = initparams.loginusername;
//   formname = initparams.formname;
//   reportname = initparams.reportname;
//   console.log("++++++++++", formname);
//   // var usename=initparams.loginUser;
//   // console.log("usename:",usename);
//   // loginuser=usename;
// }